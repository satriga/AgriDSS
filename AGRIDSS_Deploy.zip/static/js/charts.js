/**
 * IMD Gridded Rainfall Charts Module
 * Interactive Chart.js visualizations for point time-series
 * and national category distribution.
 */

class IMDCharts {
  constructor() {
    this.timeSeriesChart = null;
    this.distributionChart = null;
    this.historicalTrendChart = null;
    this.historicalSpiChart = null;
    this.monthlyNormalsChart = null;
    this.forecastChart = null;
  }

  renderPointTimeSeries(canvasId, seriesData, activeDate = null) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.timeSeriesChart) {
      this.timeSeriesChart.destroy();
    }

    const labels = seriesData.map(d => {
      // Format '2024-07-15' to 'Jul 15'
      const parts = d.date.split('-');
      const m = parseInt(parts[1], 10);
      const day = parseInt(parts[2], 10);
      const monthNames = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return `${monthNames[m]} ${day}`;
    });

    const values = seriesData.map(d => d.rainfall);

    // Compute 3-point moving average for trendline
    const trend = [];
    for (let i = 0; i < values.length; i++) {
      const windowSlice = values.slice(Math.max(0, i - 1), Math.min(values.length, i + 2));
      const avg = windowSlice.reduce((a, b) => a + b, 0) / windowSlice.length;
      trend.push(Number(avg.toFixed(1)));
    }

    // Bar colors: highlight active date with bright cyan/amber
    const barColors = seriesData.map(d => {
      if (d.date === activeDate) return '#38bdf8';
      if (d.rainfall >= 115.6) return '#ef4444';
      if (d.rainfall >= 64.5) return '#facc15';
      if (d.rainfall >= 15.6) return '#4ade80';
      if (d.rainfall >= 0.1) return '#7dd3fc';
      return '#334155';
    });

    this.timeSeriesChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            type: 'line',
            label: '3-Day Moving Avg (mm)',
            data: trend,
            borderColor: '#f59e0b',
            borderWidth: 2,
            pointRadius: 0,
            tension: 0.35,
            yAxisID: 'y'
          },
          {
            type: 'bar',
            label: 'Daily Rainfall (mm)',
            data: values,
            backgroundColor: barColors,
            borderRadius: 4,
            yAxisID: 'y'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: {
              boxWidth: 12,
              font: { size: 11, family: "'Inter', sans-serif" },
              color: '#94a3b8'
            }
          },
          tooltip: {
            backgroundColor: '#0f172a',
            borderColor: '#38bdf8',
            borderWidth: 1,
            titleColor: '#f8fafc',
            bodyColor: '#cbd5e1',
            callbacks: {
              afterLabel: function(context) {
                const item = seriesData[context.dataIndex];
                return `Category: ${item.category}`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              font: { size: 10 },
              color: '#64748b',
              maxRotation: 45
            }
          },
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(51, 65, 85, 0.4)' },
            ticks: {
              font: { size: 10 },
              color: '#64748b'
            },
            title: {
              display: true,
              text: 'Rainfall (mm)',
              color: '#94a3b8',
              font: { size: 10 }
            }
          }
        }
      }
    });
  }

  renderCategoryDistribution(canvasId, categories) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.distributionChart) {
      this.distributionChart.destroy();
    }

    const labels = categories.map(c => c.name);
    const percentages = categories.map(c => c.percent);
    const colors = categories.map(c => c.color);

    this.distributionChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          data: percentages,
          backgroundColor: colors,
          borderColor: 'rgba(0, 0, 0, 0.2)',
          borderWidth: 1,
          borderRadius: 4
        }]
      },
      options: {
        indexAxis: 'y', // Horizontal bars
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#0f172a',
            borderColor: '#38bdf8',
            borderWidth: 1,
            callbacks: {
              label: function(context) {
                const cat = categories[context.dataIndex];
                return `Coverage: ${cat.percent}% (${cat.count} grid cells)`;
              }
            }
          }
        },
        scales: {
          x: {
            beginAtZero: true,
            max: 100,
            grid: { color: 'rgba(51, 65, 85, 0.3)' },
            ticks: {
              callback: val => `${val}%`,
              font: { size: 10 },
              color: '#64748b'
            }
          },
          y: {
            grid: { display: false },
            ticks: {
              font: { size: 11 },
              color: '#94a3b8'
            }
          }
        }
      }
    });
  }

  renderHistoricalTrendChart(canvasId, timeline, annualNormal) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.historicalTrendChart) {
      this.historicalTrendChart.destroy();
    }

    const labels = timeline.map(t => t.year);
    const rainVals = timeline.map(t => t.annual_rainfall);
    const normalLine = timeline.map(() => annualNormal);

    // Bar colors based on departure %
    const barColors = timeline.map(t => {
      const dep = t.departure_pct;
      if (dep <= -25.0) return '#dc2626'; // Severe deficit
      if (dep <= -10.0) return '#f59e0b'; // Moderate deficit
      if (dep >= 25.0) return '#2563eb';  // Excess
      if (dep >= 10.0) return '#0284c7';  // Above normal
      return '#22c55e'; // Normal
    });

    this.historicalTrendChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            type: 'line',
            label: `IMD LPA Climatological Normal (${annualNormal} mm)`,
            data: normalLine,
            borderColor: '#f43f5e',
            borderWidth: 2,
            borderDash: [5, 5],
            pointRadius: 0,
            fill: false,
            yAxisID: 'y'
          },
          {
            type: 'bar',
            label: 'Annual Rainfall (mm)',
            data: rainVals,
            backgroundColor: barColors,
            borderRadius: 2,
            yAxisID: 'y'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: { boxWidth: 12, font: { size: 11 }, color: '#94a3b8' }
          },
          tooltip: {
            backgroundColor: '#0f172a',
            borderColor: '#38bdf8',
            borderWidth: 1,
            callbacks: {
              afterLabel: function(context) {
                const item = timeline[context.dataIndex];
                const depSign = item.departure_pct > 0 ? '+' : '';
                return `Departure: ${depSign}${item.departure_pct}% | SPI-12: ${item.spi_12} (${item.category})`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              font: { size: 10 },
              color: '#64748b',
              maxTicksLimit: 25
            }
          },
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(51, 65, 85, 0.4)' },
            ticks: { font: { size: 10 }, color: '#64748b' },
            title: { display: true, text: 'Precipitation (mm)', color: '#94a3b8', font: { size: 11 } }
          }
        }
      }
    });
  }

  renderHistoricalSpiChart(canvasId, timeline) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.historicalSpiChart) {
      this.historicalSpiChart.destroy();
    }

    const labels = timeline.map(t => t.year);
    const spiVals = timeline.map(t => t.spi_3 !== null ? t.spi_3 : t.spi_12);

    const barColors = spiVals.map(v => {
      if (v === null || isNaN(v)) return '#64748b';
      if (v <= -2.0) return '#dc2626'; // Extreme Drought
      if (v <= -1.5) return '#f97316'; // Moderate Drought
      if (v <= -1.0) return '#eab308'; // Mild Drought
      if (v >= 2.0) return '#1e3a8a';  // Extremely Wet
      if (v >= 1.5) return '#2563eb';  // Very Wet
      if (v >= 1.0) return '#06b6d4';  // Moderately Wet
      return '#22c55e'; // Normal
    });

    this.historicalSpiChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'SPI Drought Index (McKee / Thom MLE)',
          data: spiVals,
          backgroundColor: barColors,
          borderRadius: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#0f172a',
            borderColor: '#38bdf8',
            borderWidth: 1,
            callbacks: {
              label: function(context) {
                const item = timeline[context.dataIndex];
                const sVal = context.raw;
                return `SPI-3 (Monsoon): ${sVal} [${item.category}]`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 10 }, color: '#64748b', maxTicksLimit: 25 }
          },
          y: {
            min: -3.5,
            max: 3.5,
            grid: { color: 'rgba(51, 65, 85, 0.4)' },
            ticks: {
              stepSize: 1.0,
              font: { size: 10 },
              color: '#64748b',
              callback: val => {
                if (val === -2.0) return '-2.0 (Extreme Drought)';
                if (val === -1.5) return '-1.5 (Severe)';
                if (val === -1.0) return '-1.0 (Mild)';
                if (val === 0) return '0.0 (Normal)';
                if (val === 1.0) return '+1.0 (Moderate Wet)';
                if (val === 2.0) return '+2.0 (Extreme Wet)';
                return val;
              }
            },
            title: { display: true, text: 'Standardized Precipitation Index (SPI)', color: '#94a3b8', font: { size: 11 } }
          }
        }
      }
    });
  }

  renderMonthlyNormalsChart(canvasId, monthlyNormals) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.monthlyNormalsChart) {
      this.monthlyNormalsChart.destroy();
    }

    const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    const vals = months.map(m => monthlyNormals[m] || 0.0);

    // Highlight monsoon months (JUN, JUL, AUG, SEP) with vibrant blue
    const barColors = months.map((m, idx) => {
      if (idx >= 5 && idx <= 8) return '#0284c7';
      return '#38bdf8';
    });

    this.monthlyNormalsChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
          label: 'Climatological Normal (mm)',
          data: vals,
          backgroundColor: barColors,
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#0f172a',
            borderColor: '#38bdf8',
            borderWidth: 1,
            callbacks: {
              label: context => `Normal: ${context.raw} mm`
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 10 }, color: '#94a3b8' }
          },
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(51, 65, 85, 0.4)' },
            ticks: { font: { size: 10 }, color: '#64748b' },
            title: { display: true, text: 'Normal (mm)', color: '#94a3b8', font: { size: 10 } }
          }
        }
      }
    });
  }

  renderForecastChart(canvasId, hourlyData, selectedHourIndex = 0) {
    const ctx = document.getElementById(canvasId);
    if (!ctx || !hourlyData || hourlyData.length === 0) return;

    if (this.forecastChart) {
      this.forecastChart.destroy();
    }

    // Sample step down if 168 hours for clean graph readability
    const stepInterval = hourlyData.length > 72 ? 3 : 1;
    const sampled = [];
    for (let i = 0; i < hourlyData.length; i += stepInterval) {
      sampled.push({
        origIndex: i,
        step: hourlyData[i]
      });
    }

    const labels = sampled.map(s => {
      const parts = s.step.time.split('T');
      const d = parts[0].slice(5); // '11-01'
      const h = parts[1].slice(0, 5); // '14:00'
      return `${d} ${h}`;
    });

    const temps = sampled.map(s => s.step.temperature);
    const precips = sampled.map(s => s.step.precipitation);
    const probs = sampled.map(s => s.step.precipitation_probability);

    // Find closest sampled index for selectedHourIndex
    let activeSampledIdx = 0;
    let minDiff = 999999;
    sampled.forEach((s, idx) => {
      const diff = Math.abs(s.origIndex - selectedHourIndex);
      if (diff < minDiff) {
        minDiff = diff;
        activeSampledIdx = idx;
      }
    });

    const pointRadii = sampled.map((s, idx) => idx === activeSampledIdx ? 6 : 1.5);
    const pointBgColors = sampled.map((s, idx) => idx === activeSampledIdx ? '#ffffff' : '#f97316');
    const pointBorderColors = sampled.map((s, idx) => idx === activeSampledIdx ? '#ea580c' : '#f97316');
    const pointBorderWidths = sampled.map((s, idx) => idx === activeSampledIdx ? 3 : 1);

    this.forecastChart = new Chart(ctx, {
      data: {
        labels: labels,
        datasets: [
          {
            type: 'line',
            label: 'Temp (°C)',
            data: temps,
            borderColor: '#f97316',
            backgroundColor: 'rgba(249, 115, 22, 0.1)',
            borderWidth: 2,
            yAxisID: 'yTemp',
            tension: 0.35,
            pointRadius: pointRadii,
            pointBackgroundColor: pointBgColors,
            pointBorderColor: pointBorderColors,
            pointBorderWidth: pointBorderWidths,
            pointHoverRadius: 6
          },
          {
            type: 'bar',
            label: 'Rain (mm)',
            data: precips,
            backgroundColor: sampled.map((s, idx) => idx === activeSampledIdx ? '#0284c7' : '#38bdf8'),
            borderColor: '#0284c7',
            borderWidth: 1,
            yAxisID: 'yPrecip',
            borderRadius: 2
          },
          {
            type: 'line',
            label: 'Rain Prob (%)',
            data: probs,
            borderColor: '#a855f7',
            borderDash: [3, 3],
            borderWidth: 1.5,
            yAxisID: 'yProb',
            tension: 0.2,
            pointRadius: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        onClick: (event, elements) => {
          if (elements && elements.length > 0) {
            const elIndex = elements[0].index;
            if (sampled[elIndex] && typeof window.onForecastHourSelected === 'function') {
              window.onForecastHourSelected(sampled[elIndex].origIndex);
            }
          }
        },
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: { boxWidth: 10, font: { size: 9 }, color: '#94a3b8' }
          },
          tooltip: {
            backgroundColor: '#0f172a',
            borderColor: '#38bdf8',
            borderWidth: 1,
            callbacks: {
              afterTitle: (items) => {
                const idx = items[0].dataIndex;
                const orig = sampled[idx].step;
                return `${orig.condition} • Wind: ${orig.wind_speed} km/h ${orig.wind_compass}`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 8.5 }, color: '#64748b', maxTicksLimit: 12 }
          },
          yTemp: {
            type: 'linear',
            position: 'left',
            grid: { color: 'rgba(51, 65, 85, 0.3)' },
            ticks: { font: { size: 9 }, color: '#f97316' },
            title: { display: true, text: 'Temp (°C)', color: '#f97316', font: { size: 9 } }
          },
          yPrecip: {
            type: 'linear',
            position: 'right',
            grid: { display: false },
            ticks: { font: { size: 9 }, color: '#38bdf8' },
            title: { display: true, text: 'Rain (mm)', color: '#38bdf8', font: { size: 9 } },
            beginAtZero: true
          },
          yProb: {
            type: 'linear',
            position: 'right',
            display: false,
            min: 0,
            max: 100
          }
        }
      }
    });
  }
}

window.IMDCharts = IMDCharts;
