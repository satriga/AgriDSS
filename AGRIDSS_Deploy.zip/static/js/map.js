/**
 * IMD Gridded Rainfall GIS Map Module
 * Custom Leaflet Canvas Raster Layer, Color Palettes,
 * State Boundaries, and Spatial Probing.
 */

class IMDMapViewer {
  constructor(containerId, options = {}) {
    this.containerId = containerId;
    this.options = options;
    this.map = null;
    this.canvasLayer = null;
    this.stateGeoJsonLayer = null;
    this.hotspotLayer = null;
    this.selectedMarker = null;

    // Grid data
    this.gridMeta = null;
    this.gridValues = null; // 1D array of floats or nulls
    this.colorPalette = 'imd'; // 'imd', 'turbo', 'viridis', 'blues'
    this.renderMode = 'smooth'; // 'smooth' (bilinear canvas) or 'cells' (discrete rectangles)
    this.opacity = 0.85;
    this.showStates = true;
    this.showHotspots = true;
    this.isSpiMode = false;
    this.spiTimescale = 3;

    // Callbacks
    this.onPointClick = options.onPointClick || null;
    this.onMouseMove = options.onMouseMove || null;

    this.initMap();
  }

  initMap() {
    // Center of India
    const indiaCenter = [22.5, 82.0];

    // CARTO Basemap API Configuration
    this.cartoApiKey = 'cb1_4yvv_1_4586f512f6998012381a9f15';
    this.cartoConfig = {
      apiKey: this.cartoApiKey,
      rasterVoyagerUrl: `https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png?key=${this.cartoApiKey}`,
      rasterVoyagerSubdomainsUrl: `https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png?key=${this.cartoApiKey}`,
      vectorStyleUrl: `https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json?key=${this.cartoApiKey}`
    };
    window.CARTO_CONFIG = this.cartoConfig;

    // Basemaps with Official CARTO API Key
    const cartoVoyager = L.tileLayer(`https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png?key=${this.cartoApiKey}`, {
      attribution: '&copy; <a href="https://carto.com/" target="_blank">CARTO</a> &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
      subdomains: 'abcd',
      maxZoom: 19
    });

    const cartoDark = L.tileLayer(`https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png?key=${this.cartoApiKey}`, {
      attribution: '&copy; <a href="https://carto.com/" target="_blank">CARTO</a> &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
      subdomains: 'abcd',
      maxZoom: 19
    });

    const cartoLight = L.tileLayer(`https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png?key=${this.cartoApiKey}`, {
      attribution: '&copy; <a href="https://carto.com/" target="_blank">CARTO</a> &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
      subdomains: 'abcd',
      maxZoom: 19
    });

    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
      maxZoom: 19
    });

    const esriSat = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      attribution: '&copy; Esri &copy; DigitalGlobe',
      maxZoom: 18
    });

    this.baseLayers = {
      voyager: cartoVoyager,
      dark: cartoDark,
      positron: cartoLight,
      osm: osm,
      satellite: esriSat
    };

    this.map = L.map(this.containerId, {
      center: indiaCenter,
      zoom: 5,
      minZoom: 4,
      maxZoom: 12,
      layers: [cartoVoyager],
      zoomControl: false
    });

    // Add zoom control top right
    L.control.zoom({ position: 'topright' }).addTo(this.map);

    // Layer control
    const baseLayersControl = {
      "CARTO Voyager (API Key)": cartoVoyager,
      "CARTO Dark Matter (API Key)": cartoDark,
      "CARTO Positron Light (API Key)": cartoLight,
      "OpenStreetMap Standard": osm,
      "ESRI Satellite World Imagery": esriSat
    };
    this.layersControl = L.control.layers(baseLayersControl, null, { position: 'topright', collapsed: true }).addTo(this.map);

    // Hotspot layer group
    this.hotspotLayer = L.layerGroup().addTo(this.map);

    // Setup Custom Canvas Raster Layer
    this.setupCanvasLayer();

    // Load India State Boundaries
    this.loadStateBoundaries();

    // Map Event Listeners
    this.map.on('mousemove', (e) => this.handleMouseMove(e));
    this.map.on('click', (e) => this.handleMapClick(e));
  }

  setBasemap(name) {
    if (!this.baseLayers || !this.baseLayers[name]) return;
    Object.values(this.baseLayers).forEach(layer => {
      if (this.map.hasLayer(layer)) {
        this.map.removeLayer(layer);
      }
    });
    this.baseLayers[name].addTo(this.map);
    this.currentBaseLayer = this.baseLayers[name];
  }

  setupCanvasLayer() {
    const CanvasOverlay = L.Layer.extend({
      onAdd: (map) => {
        this._canvas = L.DomUtil.create('canvas', 'leaflet-imd-canvas');
        this._canvas.style.position = 'absolute';
        this._canvas.style.pointerEvents = 'none';
        this._canvas.style.zIndex = '200';
        map.getPanes().overlayPane.appendChild(this._canvas);

        map.on('moveend resize zoom', this.redrawCanvas, this);
        this.redrawCanvas();
      },
      onRemove: (map) => {
        map.getPanes().overlayPane.removeChild(this._canvas);
        map.off('moveend resize zoom', this.redrawCanvas, this);
      }
    });

    this.canvasOverlay = new CanvasOverlay();
    this.map.addLayer(this.canvasOverlay);
  }

  loadStateBoundaries() {
    fetch('/api/india_states')
      .then(res => res.json())
      .then(data => {
        if (!data || !data.features || data.features.length === 0) return;

        // Dedicated custom pane for India shapefile vectors above raster canvas
        if (!this.map.getPane('indiaShapefilePane')) {
          const p = this.map.createPane('indiaShapefilePane');
          p.style.zIndex = '450'; // Above canvas overlay (200), below markers/popups (600)
          p.style.pointerEvents = 'auto';
        }

        this.stateGeoJsonLayer = L.geoJSON(data, {
          pane: 'indiaShapefilePane',
          style: {
            color: '#0284c7', // High-contrast marine sky blue
            weight: 1.5,
            opacity: 0.9,
            fillOpacity: 0.0,
            dashArray: '3, 4'
          },
          onEachFeature: (feature, layer) => {
            const name = feature.properties.ST_NM || feature.properties.state_name || feature.properties.NAME_1 || 'State';
            layer.bindTooltip(`<strong>${name}</strong>`, {
              sticky: true,
              className: 'state-tooltip'
            });
            layer.on({
              mouseover: (e) => {
                const l = e.target;
                l.setStyle({ weight: 2.5, color: '#f59e0b', opacity: 1.0 });
              },
              mouseout: (e) => {
                this.stateGeoJsonLayer.resetStyle(e.target);
              }
            });
          }
        });

        if (this.showStates) {
          this.stateGeoJsonLayer.addTo(this.map);
        }
      })
      .catch(err => console.warn('Could not load states geojson:', err));
  }

  setGridData(gridMeta, topPoints = []) {
    this.gridMeta = gridMeta;
    this.gridValues = gridMeta.values; // flat array (129 * 135)
    this._mercatorCanvas = null;
    this.redrawCanvas();
    this.updateHotspots(topPoints);
  }

  /**
   * Resolves the projection distortion between IMD Geographic WGS84 (EPSG:4326)
   * regular equirectangular grid and Leaflet's Web Mercator (EPSG:3857) conformal projection.
   * Generates a high-resolution Mercator-reprojected offscreen raster.
   */
  buildMercatorRaster() {
    if (!this.gridMeta || !this.gridValues) return;

    const { nlat, nlon, lat0, lon0, step, lat_end, lon_end } = this.gridMeta;
    const halfStep = step / 2.0;

    const lat_min = lat0 - halfStep; // 6.375
    const lat_max = lat_end + halfStep; // 38.625
    const lon_min = lon0 - halfStep; // 66.375
    const lon_max = lon_end + halfStep; // 100.125

    // Web Mercator bounds
    const y_m_max = Math.log(Math.tan(Math.PI / 4.0 + (lat_max * Math.PI / 180.0) / 2.0));
    const y_m_min = Math.log(Math.tan(Math.PI / 4.0 + (lat_min * Math.PI / 180.0) / 2.0));
    const y_m_range = y_m_max - y_m_min;

    // High-resolution Mercator raster target (540 x 512 for ultra-crisp resolution)
    const W_m = nlon * 4; // 540 px
    const H_m = 512;      // 512 px

    if (!this._mercatorCanvas) {
      this._mercatorCanvas = document.createElement('canvas');
      this._mercatorCanvas.width = W_m;
      this._mercatorCanvas.height = H_m;
    }

    const ctx = this._mercatorCanvas.getContext('2d');
    const imgData = ctx.createImageData(W_m, H_m);
    const data = imgData.data;

    // Precalculate row mappings from Mercator y to IMD grid float row
    const rowMapping = new Float32Array(H_m);
    for (let ym = 0; ym < H_m; ym++) {
      const y_norm = ym / (H_m - 1);
      const ym_val = y_m_max - y_norm * y_m_range;
      const lat_deg = (2.0 * Math.atan(Math.exp(ym_val)) - Math.PI / 2.0) * (180.0 / Math.PI);
      rowMapping[ym] = (lat_deg - lat0) / step;
    }

    // Precalculate col mappings from Mercator x to IMD grid float col
    const colMapping = new Float32Array(W_m);
    for (let xm = 0; xm < W_m; xm++) {
      const x_norm = xm / (W_m - 1);
      const lon_deg = lon_min + x_norm * (lon_max - lon_min);
      colMapping[xm] = (lon_deg - lon0) / step;
    }

    const isValid = (v) => this.isSpiMode
      ? (v !== null && v !== undefined && !isNaN(v))
      : (v !== null && v !== undefined && !isNaN(v) && v >= 0.1);

    for (let ym = 0; ym < H_m; ym++) {
      const r_float = rowMapping[ym];
      const r0 = Math.floor(r_float);
      const r1 = r0 + 1;
      const dr = r_float - r0;
      const rowOffset = ym * W_m * 4;

      for (let xm = 0; xm < W_m; xm++) {
        const c_float = colMapping[xm];
        const c0 = Math.floor(c_float);
        const c1 = c0 + 1;
        const dc = c_float - c0;
        const pxIdx = rowOffset + xm * 4;

        // Sample neighboring cells
        const inBounds0 = r0 >= 0 && r0 < nlat;
        const inBounds1 = r1 >= 0 && r1 < nlat;
        const inBoundsC0 = c0 >= 0 && c0 < nlon;
        const inBoundsC1 = c1 >= 0 && c1 < nlon;

        const v00 = (inBounds0 && inBoundsC0) ? this.gridValues[r0 * nlon + c0] : null;
        const v01 = (inBounds0 && inBoundsC1) ? this.gridValues[r0 * nlon + c1] : null;
        const v10 = (inBounds1 && inBoundsC0) ? this.gridValues[r1 * nlon + c0] : null;
        const v11 = (inBounds1 && inBoundsC1) ? this.gridValues[r1 * nlon + c1] : null;

        const nearestR = Math.round(r_float);
        const nearestC = Math.round(c_float);
        let val = (nearestR >= 0 && nearestR < nlat && nearestC >= 0 && nearestC < nlon)
          ? this.gridValues[nearestR * nlon + nearestC]
          : null;

        if (!isValid(val)) {
          data[pxIdx + 3] = 0; // Transparent
        } else {
          // Smooth bilinear interpolation if surrounding cells are valid land data
          if (isValid(v00) && isValid(v01) && isValid(v10) && isValid(v11)) {
            val = (1 - dr) * ((1 - dc) * v00 + dc * v01) + dr * ((1 - dc) * v10 + dc * v11);
          }
          const rgb = this.isSpiMode ? this.getRgbForSpi(val) : this.getRgbForRainfall(val);
          data[pxIdx] = rgb[0];
          data[pxIdx + 1] = rgb[1];
          data[pxIdx + 2] = rgb[2];
          data[pxIdx + 3] = (!this.isSpiMode && val < 2.5) ? 180 : 235;
        }
      }
    }

    ctx.putImageData(imgData, 0, 0);
  }

  redrawCanvas() {
    if (!this._canvas || !this.gridMeta || !this.gridValues) return;

    const map = this.map;
    const canvas = this._canvas;
    const ctx = canvas.getContext('2d');

    const size = map.getSize();
    const bounds = map.getBounds();
    const topLeft = map.containerPointToLayerPoint([0, 0]);

    L.DomUtil.setPosition(canvas, topLeft);
    canvas.width = size.x;
    canvas.height = size.y;
    ctx.clearRect(0, 0, size.x, size.y);

    const { nlat, nlon, lat0, lon0, step, lat_end, lon_end } = this.gridMeta;
    const halfStep = step / 2.0;

    ctx.globalAlpha = this.opacity;

    if (this.renderMode === 'cells') {
      // Discrete rectangular grid cells in EPSG:3857 projection
      for (let r = 0; r < nlat; r++) {
        const lat = lat0 + r * step;
        if (lat + halfStep < bounds.getSouth() || lat - halfStep > bounds.getNorth()) continue;

        for (let c = 0; c < nlon; c++) {
          const lon = lon0 + c * step;
          if (lon + halfStep < bounds.getWest() || lon - halfStep > bounds.getEast()) continue;

          const val = this.gridValues[r * nlon + c];
          const isInvalid = this.isSpiMode
            ? (val === null || val === undefined || isNaN(val))
            : (val === null || val === undefined || isNaN(val) || val < 0.1);
          if (isInvalid) continue;

          const color = this.isSpiMode ? this.getColorForSpi(val) : this.getColorForRainfall(val);

          // Get exact pixel bounds for cell in Web Mercator
          const pTopLeft = map.latLngToContainerPoint([lat + halfStep, lon - halfStep]);
          const pBottomRight = map.latLngToContainerPoint([lat - halfStep, lon + halfStep]);

          const x = pTopLeft.x;
          const y = pTopLeft.y;
          const w = pBottomRight.x - pTopLeft.x;
          const h = pBottomRight.y - pTopLeft.y;

          ctx.fillStyle = color;
          ctx.fillRect(x, y, w + 0.35, h + 0.35);

          // If zoomed in close, draw cell outline
          if (map.getZoom() >= 8) {
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
            ctx.lineWidth = 0.5;
            ctx.strokeRect(x, y, w, h);
          }
        }
      }
    } else {
      // High-performance Web Mercator (EPSG:3857) re-projected smooth raster
      if (!this._mercatorCanvas) {
        this.buildMercatorRaster();
      }

      // Project grid bounding box to screen coordinates in Web Mercator
      const nw = map.latLngToContainerPoint([lat_end + halfStep, lon0 - halfStep]);
      const se = map.latLngToContainerPoint([lat0 - halfStep, lon_end + halfStep]);

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(this._mercatorCanvas, nw.x, nw.y, se.x - nw.x, se.y - nw.y);
    }
  }

  updateHotspots(topPoints) {
    this.hotspotLayer.clearLayers();
    if (!this.showHotspots || !topPoints || topPoints.length === 0) return;

    // Show top 5 peak centers
    topPoints.slice(0, 5).forEach((pt, idx) => {
      if (pt.rainfall < 15.6) return; // Only highlight moderate/heavy rain

      const isExtreme = pt.rainfall >= 115.6;
      const markerColor = isExtreme ? '#ef4444' : '#f59e0b';

      const iconHtml = `
        <div class="pulse-marker" style="
          width: 24px; height: 24px;
          border-radius: 50%;
          background: ${markerColor};
          border: 2px solid #fff;
          box-shadow: 0 0 10px ${markerColor};
          display: flex; align-items: center; justify-content: center;
          color: #fff; font-size: 10px; font-weight: 700;
        ">
          ${idx + 1}
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-pulse-pin',
        html: iconHtml,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });

      const m = L.marker([pt.lat, pt.lon], { icon: customIcon });
      m.bindPopup(`
        <div style="font-family: 'Inter', sans-serif; font-size: 12px;">
          <strong>#${idx + 1} ${pt.location}</strong><br/>
          <span>Rainfall: <b style="color:${markerColor}">${pt.rainfall} mm</b></span><br/>
          <span style="font-size:11px; color:#64748b;">(${pt.category})</span><br/>
          <small>Lat: ${pt.lat}°N, Lon: ${pt.lon}°E</small>
        </div>
      `);
      this.hotspotLayer.addLayer(m);
    });
  }

  setSpiMode(isSpi, timescale = 3) {
    this.isSpiMode = isSpi;
    this.spiTimescale = timescale;
    this._mercatorCanvas = null;
    this.redrawCanvas();
  }

  getColorForSpi(val) {
    const rgb = this.getRgbForSpi(val);
    return `rgb(${rgb[0]}, ${rgb[1]}, ${rgb[2]})`;
  }

  getRgbForSpi(val) {
    if (val === null || val === undefined || isNaN(val)) return [51, 65, 85];
    if (val <= -2.0) return [220, 38, 38];    // Deep Red (Extreme Drought)
    if (val <= -1.5) return [249, 115, 22];   // Orange (Moderate Drought)
    if (val <= -1.0) return [234, 179, 8];    // Amber (Mild Drought)
    if (val < 1.0)   return [34, 197, 94];    // Green (Near Normal)
    if (val < 1.5)   return [6, 182, 212];    // Cyan (Moderately Wet)
    if (val < 2.0)   return [37, 99, 235];    // Blue (Very Wet)
    return [30, 58, 138];                     // Deep Blue (Extremely Wet)
  }

  getColorForRainfall(val) {
    const rgb = this.getRgbForRainfall(val);
    return `rgb(${rgb[0]}, ${rgb[1]}, ${rgb[2]})`;
  }

  getRgbForRainfall(val) {
    if (this.colorPalette === 'turbo') {
      // Turbo Colormap
      return this.interpolateTurbo(val / 150.0);
    } else if (this.colorPalette === 'viridis') {
      return this.interpolateViridis(val / 150.0);
    } else if (this.colorPalette === 'blues') {
      return this.interpolateBlues(val / 150.0);
    }

    // Default: Official IMD Rainfall Classification
    if (val < 0.1) return [248, 250, 252];
    if (val < 2.5) return [186, 230, 253];   // Light Sky Blue
    if (val < 15.6) return [56, 189, 248];   // Vibrant Cyan
    if (val < 64.5) return [74, 222, 128];   // Green
    if (val < 115.6) return [250, 204, 21];  // Yellow/Amber
    if (val < 204.5) return [251, 146, 60];  // Orange
    return [220, 38, 38];                   // Intense Red/Crimson
  }

  interpolateBlues(t) {
    const clamped = Math.min(Math.max(t, 0), 1);
    const r = Math.round(240 - clamped * 220);
    const g = Math.round(248 - clamped * 180);
    const b = Math.round(255 - clamped * 50);
    return [r, g, b];
  }

  interpolateViridis(t) {
    const c = Math.min(Math.max(t, 0), 1);
    const r = Math.round(68 + c * (253 - 68));
    const g = Math.round(1 + c * (231 - 1));
    const b = Math.round(84 + (1 - c) * 80);
    return [r, g, b];
  }

  interpolateTurbo(t) {
    const x = Math.min(Math.max(t, 0), 1);
    const r = Math.round(255 * Math.sin(x * Math.PI));
    const g = Math.round(255 * Math.sin((x + 0.3) * Math.PI));
    const b = Math.round(255 * Math.cos(x * Math.PI * 0.5));
    return [Math.max(0, r), Math.max(0, g), Math.max(0, b)];
  }

  getRainfallAt(lat, lon) {
    if (!this.gridMeta || !this.gridValues) return null;

    const { nlat, nlon, lat0, lon0, step, lat_end, lon_end } = this.gridMeta;
    if (lat < lat0 - step/2 || lat > lat_end + step/2 || lon < lon0 - step/2 || lon > lon_end + step/2) {
      return null;
    }

    const r = Math.round((lat - lat0) / step);
    const c = Math.round((lon - lon0) / step);

    if (r < 0 || r >= nlat || c < 0 || c >= nlon) return null;

    const val = this.gridValues[r * nlon + c];
    return {
      lat: Number((lat0 + r * step).toFixed(2)),
      lon: Number((lon0 + c * step).toFixed(2)),
      value: val !== null && !isNaN(val) ? val : null,
      rainfall: (!this.isSpiMode && val !== null && !isNaN(val)) ? val : null,
      spi: (this.isSpiMode && val !== null && !isNaN(val)) ? val : null
    };
  }

  handleMouseMove(e) {
    const lat = e.latlng.lat;
    const lon = e.latlng.lng;
    const ptData = this.getRainfallAt(lat, lon);

    if (this.onMouseMove) {
      this.onMouseMove(lat, lon, ptData);
    }
  }

  handleMapClick(e) {
    const lat = Number(e.latlng.lat.toFixed(4));
    const lon = Number(e.latlng.lng.toFixed(4));
    const ptData = this.getRainfallAt(lat, lon);

    // Place selection pin
    if (this.selectedMarker) {
      this.map.removeLayer(this.selectedMarker);
    }

    const pinHtml = `
      <div style="
        width: 14px; height: 14px;
        background: #38bdf8;
        border: 2px solid #ffffff;
        border-radius: 50%;
        box-shadow: 0 0 8px #38bdf8;
      "></div>
    `;

    this.selectedMarker = L.marker([lat, lon], {
      icon: L.divIcon({ className: 'probe-pin', html: pinHtml, iconSize: [14, 14], iconAnchor: [7, 7] })
    }).addTo(this.map);

    if (this.onPointClick) {
      this.onPointClick(lat, lon, ptData);
    }
  }

  zoomTo(lat, lon, zoom = 8) {
    this.map.flyTo([lat, lon], zoom, { duration: 1.2 });
  }

  resetView() {
    this.map.flyTo([22.5, 82.0], 5, { duration: 1.0 });
  }

  toggleStates(show) {
    this.showStates = show;
    if (this.stateGeoJsonLayer) {
      if (show) {
        this.stateGeoJsonLayer.addTo(this.map);
      } else {
        this.map.removeLayer(this.stateGeoJsonLayer);
      }
    }
  }

  toggleHotspots(show) {
    this.showHotspots = show;
    if (show) {
      this.hotspotLayer.addTo(this.map);
    } else {
      this.map.removeLayer(this.hotspotLayer);
    }
  }

  setPalette(palette) {
    this.colorPalette = palette;
    this._mercatorCanvas = null;
    this.redrawCanvas();
  }

  setRenderMode(mode) {
    this.renderMode = mode;
    this.redrawCanvas();
  }

  setOpacity(val) {
    this.opacity = parseFloat(val);
    this.redrawCanvas();
  }
}

window.IMDMapViewer = IMDMapViewer;
