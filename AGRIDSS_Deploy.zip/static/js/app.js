/**
 * IMD Gridded Rainfall Main Application Controller
 * Coordinates Map, Charts, Playback Timeline, API calls, and UI state.
 */

document.addEventListener('DOMContentLoaded', () => {
  // App State
  const state = {
    dates: [],
    currentDateIndex: 0,
    currentDate: null,
    variable: 'rainfall', // 'rainfall' or 'spi'
    spiSubMode: 'timescale', // 'timescale' or 'range'
    spiTimescale: 3,      // 1, 3, 6, 12
    spiStartDate: null,
    spiEndDate: null,
    mode: 'daily',        // 'daily' or 'accumulate'
    accumDays: 7,
    startDate: null,
    endDate: null,
    currentStats: null,
    isPlaying: false,
    playInterval: null,
    playbackSpeed: 1200,  // ms per frame
    selectedPoint: { lat: 18.52, lon: 73.85 }, // default to Pune, Maharashtra
    currentDistrict: 'Pune, Maharashtra',
    currentDistrictRecord: null,
    districtsList: [],
    statesHierarchy: {},
    selectedStateFilter: 'all',
    selectedCategoryFilter: 'all',
    districtSearchQuery: '',
    theme: 'dark',
    viewMode: 'imd', // 'imd', 'forecast', or 'windy'
    windyOverlay: 'wind', // 'wind', 'radar', 'rain', 'temp', 'clouds', 'pressure', 'gust', 'rh'
    windyZoom: 5,
    windyCenter: { lat: 20.5937, lon: 78.9629 },
    liveWeather: null,
    forecastData: null,
    forecastStepIndex: 0,
    isForecastPlaying: false,
    forecastPlayInterval: null,
    forecastSpeed: 1000
  };

  // UI Element References
  const els = {
    // Header
    themeToggleBtn: document.getElementById('themeToggleBtn'),
    infoModalBtn: document.getElementById('infoModalBtn'),
    infoModal: document.getElementById('infoModal'),
    closeModalBtn: document.getElementById('closeModalBtn'),
    headerMaxRain: document.getElementById('headerMaxRain'),
    headerMeanRain: document.getElementById('headerMeanRain'),
    headerCoverage: document.getElementById('headerCoverage'),
    headerVolume: document.getElementById('headerVolume'),
    headerSyncStatus: document.getElementById('headerSyncStatus'),
    btnHeaderSync: document.getElementById('btnHeaderSync'),
    syncIcon: document.getElementById('syncIcon'),
    btnHeaderHistory: document.getElementById('btnHeaderHistory'),
    
    // Left Sidebar Variable & District Controls
    varRainfallBtn: document.getElementById('varRainfallBtn'),
    varSpiBtn: document.getElementById('varSpiBtn'),
    activeVariableBadge: document.getElementById('activeVariableBadge'),
    spiTimescaleGroup: document.getElementById('spiTimescaleGroup'),
    btnSpiSubTimescale: document.getElementById('btnSpiSubTimescale'),
    btnSpiSubRange: document.getElementById('btnSpiSubRange'),
    spiTimescaleSelectWrapper: document.getElementById('spiTimescaleSelectWrapper'),
    spiTimescaleSelect: document.getElementById('spiTimescaleSelect'),
    spiCustomRangeControls: document.getElementById('spiCustomRangeControls'),
    spiStartDate: document.getElementById('spiStartDate'),
    spiEndDate: document.getElementById('spiEndDate'),
    btnApplySpiRange: document.getElementById('btnApplySpiRange'),
    spiCalculationDatesBadge: document.getElementById('spiCalculationDatesBadge'),
    spiModeTypeBadge: document.getElementById('spiModeTypeBadge'),
    spiWindowLabel: document.getElementById('spiWindowLabel'),
    sidebarStateSelect: document.getElementById('sidebarStateSelect'),
    sidebarDistrictSelect: document.getElementById('sidebarDistrictSelect'),
    districtSearchInput: document.getElementById('districtSearchInput'),
    districtsDatalist: document.getElementById('districtsDatalist'),
    btnAnalyzeDistrict: document.getElementById('btnAnalyzeDistrict'),
    btnOpenDistrictsTable: document.getElementById('btnOpenDistrictsTable'),

    // Analysis Mode
    modeDailyBtn: document.getElementById('modeDailyBtn'),
    modeAccumBtn: document.getElementById('modeAccumBtn'),
    dateInput: document.getElementById('dateInput'),
    accumControls: document.getElementById('accumControls'),
    accumPeriodSelect: document.getElementById('accumPeriodSelect'),
    customRangeGroup: document.getElementById('customRangeGroup'),
    accumStartDate: document.getElementById('accumStartDate'),
    accumEndDate: document.getElementById('accumEndDate'),
    applyAccumBtn: document.getElementById('applyAccumBtn'),
    presetChips: document.querySelectorAll('.preset-chip'),

    // Player
    playPauseBtn: document.getElementById('playPauseBtn'),
    playIcon: document.getElementById('playIcon'),
    stepPrevBtn: document.getElementById('stepPrevBtn'),
    stepNextBtn: document.getElementById('stepNextBtn'),
    speedSelect: document.getElementById('speedSelect'),
    timelineSlider: document.getElementById('timelineSlider'),
    timelineDateLabel: document.getElementById('timelineDateLabel'),

    // Map Overlays, Legends & HUD
    hudDate: document.getElementById('hudDate'),
    hudMax: document.getElementById('hudMax'),
    hudMean: document.getElementById('hudMean'),
    mouseCoordsLabel: document.getElementById('mouseCoordsLabel'),
    mouseValLabel: document.getElementById('mouseValLabel'),
    loadingOverlay: document.getElementById('loadingOverlay'),
    loadingText: document.getElementById('loadingText'),
    legendTitleMain: document.getElementById('legendTitleMain'),
    legendTitleSub: document.getElementById('legendTitleSub'),
    rainfallLegendScale: document.getElementById('rainfallLegendScale'),
    spiLegendScale: document.getElementById('spiLegendScale'),

    // Visualization Options
    basemapSelect: document.getElementById('basemapSelect'),
    paletteSelect: document.getElementById('paletteSelect'),
    renderModeSelect: document.getElementById('renderModeSelect'),
    opacitySlider: document.getElementById('opacitySlider'),
    opacityValue: document.getElementById('opacityValue'),
    toggleStatesSwitch: document.getElementById('toggleStatesSwitch'),
    toggleHotspotsSwitch: document.getElementById('toggleHotspotsSwitch'),
    btnResetView: document.getElementById('btnResetView'),

    // Fetch & Upload
    fetchDateInput: document.getElementById('fetchDateInput'),
    btnFetchImd: document.getElementById('btnFetchImd'),
    fetchStatus: document.getElementById('fetchStatus'),
    fileInput: document.getElementById('fileInput'),
    dropzone: document.getElementById('dropzone'),
    uploadStatus: document.getElementById('uploadStatus'),

    // Export
    btnExportCsv: document.getElementById('btnExportCsv'),
    btnExportGeoJson: document.getElementById('btnExportGeoJson'),

    // Right Tabs & Panels
    tabBtns: document.querySelectorAll('.tab-btn'),
    tabPanes: document.querySelectorAll('.tab-pane'),
    
    // Inspector Elements
    inspectorCoords: document.getElementById('inspectorCoords'),
    inspectorLandmark: document.getElementById('inspectorLandmark'),
    inspectorVal: document.getElementById('inspectorVal'),
    inspectorUnit: document.getElementById('inspectorUnit'),
    inspectorCategory: document.getElementById('inspectorCategory'),
    inspectorDistrictLabel: document.getElementById('inspectorDistrictLabel'),
    pointSpi1: document.getElementById('pointSpi1'),
    pointSpi2: document.getElementById('pointSpi2'),
    pointSpi3: document.getElementById('pointSpi3'),
    pointSpi6: document.getElementById('pointSpi6'),
    pointSpi12: document.getElementById('pointSpi12'),
    pointSpi24: document.getElementById('pointSpi24'),
    pointSpi1Dates: document.getElementById('pointSpi1Dates'),
    pointSpi2Dates: document.getElementById('pointSpi2Dates'),
    pointSpi3Dates: document.getElementById('pointSpi3Dates'),
    pointSpi6Dates: document.getElementById('pointSpi6Dates'),
    pointSpi12Dates: document.getElementById('pointSpi12Dates'),
    pointSpi24Dates: document.getElementById('pointSpi24Dates'),
    pointSpiRangeCard: document.getElementById('pointSpiRangeCard'),
    pointSpiRangeVal: document.getElementById('pointSpiRangeVal'),
    pointSpiRangeWindowLabel: document.getElementById('pointSpiRangeWindowLabel'),
    pointSpiRangeBadge: document.getElementById('pointSpiRangeBadge'),
    pointSpiRefDate: document.getElementById('pointSpiRefDate'),
    btnDistrictHistoryFromProbe: document.getElementById('btnDistrictHistoryFromProbe'),
    inspectorAccumVal: document.getElementById('inspectorAccumVal'),
    inspectorRainyDays: document.getElementById('inspectorRainyDays'),

    // Live Weather Parameters Elements
    liveWeatherCard: document.getElementById('liveWeatherCard'),
    liveWeatherConditionBadge: document.getElementById('liveWeatherConditionBadge'),
    liveWeatherCondition: document.getElementById('liveWeatherCondition'),
    liveWeatherIcon: document.getElementById('liveWeatherIcon'),
    liveWeatherTemp: document.getElementById('liveWeatherTemp'),
    liveWeatherFeels: document.getElementById('liveWeatherFeels'),
    liveWeatherWind: document.getElementById('liveWeatherWind'),
    liveWeatherCompass: document.getElementById('liveWeatherCompass'),
    liveWeatherDeg: document.getElementById('liveWeatherDeg'),
    liveWeatherGusts: document.getElementById('liveWeatherGusts'),
    liveWeatherHumidity: document.getElementById('liveWeatherHumidity'),
    liveWeatherPressure: document.getElementById('liveWeatherPressure'),
    liveWeatherClouds: document.getElementById('liveWeatherClouds'),
    liveWeatherPrecip: document.getElementById('liveWeatherPrecip'),
    btnInspectPointInWindy: document.getElementById('btnInspectPointInWindy'),

    // Map View & Windy Live Weather Engine Elements
    mapViewToggleBar: document.getElementById('mapViewToggleBar'),
    btnViewImd: document.getElementById('btnViewImd'),
    btnViewWindy: document.getElementById('btnViewWindy'),
    btnHeaderWindy: document.getElementById('btnHeaderWindy'),
    btnSidebarLaunchWindy: document.getElementById('btnSidebarLaunchWindy'),
    windyContainer: document.getElementById('windyContainer'),
    windyIframe: document.getElementById('windyIframe'),
    windyChipBtns: document.querySelectorAll('.windy-chip'),
    btnWindySyncPoint: document.getElementById('btnWindySyncPoint'),
    windySyncLabel: document.getElementById('windySyncLabel'),
    btnWindyAllIndia: document.getElementById('btnWindyAllIndia'),
    btnWindyExternal: document.getElementById('btnWindyExternal'),
    btnWindyClose: document.getElementById('btnWindyClose'),

    // Weather Forecast View & Slider Elements
    btnViewForecast: document.getElementById('btnViewForecast'),
    mapForecastBar: document.getElementById('mapForecastBar'),
    forecastStepBadge: document.getElementById('forecastStepBadge'),
    forecastStepLabel: document.getElementById('forecastStepLabel'),
    forecastStepPrevBtn: document.getElementById('forecastStepPrevBtn'),
    forecastPlayBtn: document.getElementById('forecastPlayBtn'),
    forecastPlayIcon: document.getElementById('forecastPlayIcon'),
    forecastStepNextBtn: document.getElementById('forecastStepNextBtn'),
    forecastSlider: document.getElementById('forecastSlider'),
    forecastQuickChips: document.querySelectorAll('.forecast-quick-chips button'),
    pointForecastSection: document.getElementById('pointForecastSection'),
    pointForecastStepBadge: document.getElementById('pointForecastStepBadge'),
    pointForecastStepTime: document.getElementById('pointForecastStepTime'),
    pointForecastCondition: document.getElementById('pointForecastCondition'),
    pointForecastIcon: document.getElementById('pointForecastIcon'),
    pointForecastTemp: document.getElementById('pointForecastTemp'),
    pointForecastRain: document.getElementById('pointForecastRain'),
    pointForecastDailyRow: document.getElementById('pointForecastDailyRow'),
    
    // Tab 782 Districts Elements
    tabBtnDistricts: document.getElementById('tabBtnDistricts'),
    districtsDateBadge: document.getElementById('districtsDateBadge'),
    distSpi1Window: document.getElementById('distSpi1Window'),
    distSpi3Window: document.getElementById('distSpi3Window'),
    btnRefreshDistrictSummary: document.getElementById('btnRefreshDistrictSummary'),
    kpiDistSevereDrought: document.getElementById('kpiDistSevereDrought'),
    kpiDistModDrought: document.getElementById('kpiDistModDrought'),
    kpiDistNormal: document.getElementById('kpiDistNormal'),
    kpiDistWet: document.getElementById('kpiDistWet'),
    tableStateFilter: document.getElementById('tableStateFilter'),
    tableCategoryFilter: document.getElementById('tableCategoryFilter'),
    tableDistrictSearch: document.getElementById('tableDistrictSearch'),
    districtsFilteredCount: document.getElementById('districtsFilteredCount'),
    districtsNatMeanRain: document.getElementById('districtsNatMeanRain'),
    districtsTableBody: document.getElementById('districtsTableBody'),
    filterChips: document.querySelectorAll('.filter-chip'),

    // Top 10 Table
    topPointsBody: document.getElementById('topPointsBody'),

    // Advisories
    advisoryContainer: document.getElementById('advisoryContainer'),

    // Historical District Modal Elements
    districtHistoryModal: document.getElementById('districtHistoryModal'),
    closeDistrictModalBtn: document.getElementById('closeDistrictModalBtn'),
    modalDistrictTitle: document.getElementById('modalDistrictTitle'),
    modalSubdivisionBadge: document.getElementById('modalSubdivisionBadge'),
    kpiAnnualNormal: document.getElementById('kpiAnnualNormal'),
    kpiMonsoonNormal: document.getElementById('kpiMonsoonNormal'),
    kpiPeakYear: document.getElementById('kpiPeakYear'),
    kpiDriestYear: document.getElementById('kpiDriestYear'),
    kpiTotalDroughts: document.getElementById('kpiTotalDroughts'),
    kpiReturnPeriod: document.getElementById('kpiReturnPeriod'),
    btnExportDistrictCsv: document.getElementById('btnExportDistrictCsv'),

    // Sidebar Toggles
    toggleLeftSidebar: document.getElementById('toggleLeftSidebar'),
    toggleRightSidebar: document.getElementById('toggleRightSidebar'),
    leftSidebar: document.getElementById('leftSidebar'),
    rightSidebar: document.getElementById('rightSidebar')
  };

  // Initialize Map and Charts
  const mapViewer = new IMDMapViewer('map', {
    onPointClick: (lat, lon, ptData) => {
      state.selectedPoint = { lat, lon };
      inspectPoint(lat, lon, ptData);
      switchTab('tab-inspector');
    },
    onMouseMove: (lat, lon, ptData) => {
      els.mouseCoordsLabel.textContent = `${lat.toFixed(2)}°N, ${lon.toFixed(2)}°E`;
      if (ptData && ptData.value !== null) {
        if (state.variable === 'spi') {
          els.mouseValLabel.textContent = `SPI: ${ptData.value.toFixed(2)}`;
        } else {
          els.mouseValLabel.textContent = `${ptData.value.toFixed(1)} mm`;
        }
      } else {
        els.mouseValLabel.textContent = '--';
      }
    }
  });

  const charts = new IMDCharts();

  // Show / Hide Loading
  function showLoading(msg = 'Processing IMD Grid Data...') {
    els.loadingText.textContent = msg;
    els.loadingOverlay.style.display = 'flex';
  }

  function hideLoading() {
    els.loadingOverlay.style.display = 'none';
  }

  // Fetch Available Dates and District List on startup
  function initApp() {
    showLoading('Initializing IMD Gridded Database & Historical Baselines...');
    
    // 1. Load dates
    fetch('/api/dates')
      .then(res => res.json())
      .then(data => {
        if (!data.success || data.count === 0) {
          alert('No IMD data files found in database.');
          hideLoading();
          return;
        }

        state.dates = data.dates;
        // Default to the latest recent 2026 data observation, or newest available date
        const dates2026 = state.dates.filter(d => d.startsWith('2026'));
        const latestTarget = dates2026.length > 0 ? dates2026[dates2026.length - 1] : state.dates[state.dates.length - 1];
        state.currentDateIndex = state.dates.indexOf(latestTarget);
        if (state.currentDateIndex === -1) state.currentDateIndex = state.dates.length - 1;
        state.currentDate = state.dates[state.currentDateIndex];

        // Setup timeline slider
        els.timelineSlider.max = state.dates.length - 1;
        els.timelineSlider.value = state.currentDateIndex;
        els.dateInput.value = state.currentDate;
        els.fetchDateInput.value = state.currentDate;

        // Set accumulation defaults
        els.accumEndDate.value = state.currentDate;
        const dStart = new Date(state.currentDate);
        dStart.setDate(dStart.getDate() - 6);
        els.accumStartDate.value = dStart.toISOString().split('T')[0];

        // Set SPI Date Range defaults
        if (els.spiEndDate) els.spiEndDate.value = state.currentDate;
        const dSpi = new Date(state.currentDate);
        dSpi.setDate(dSpi.getDate() - 89);
        if (els.spiStartDate) els.spiStartDate.value = dSpi.toISOString().split('T')[0];
        state.spiStartDate = els.spiStartDate ? els.spiStartDate.value : null;
        state.spiEndDate = els.spiEndDate ? els.spiEndDate.value : null;

        // Load grid for initial date
        loadGridData();
        // Load initial point inspection for Pune
        inspectPoint(state.selectedPoint.lat, state.selectedPoint.lon);
      })
      .catch(err => {
        console.error('Failed to init app:', err);
        hideLoading();
      });

    // 1. Load States Hierarchy & Districts list
    loadStatesHierarchy();
    loadDistrictsList();

    // 2. Check IMD Auto-Sync status
    checkSyncStatus();
  }

  // Load States Hierarchy (36 States & UTs)
  function loadStatesHierarchy() {
    fetch('/api/imd/states_hierarchy')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.states) {
          state.statesHierarchy = data.states;
          const states = Object.keys(data.states).sort();

          if (els.sidebarStateSelect) {
            els.sidebarStateSelect.innerHTML = '<option value="">-- All States & UTs (36) --</option>';
            states.forEach(st => {
              const opt = document.createElement('option');
              opt.value = st;
              opt.textContent = `${st} (${data.states[st].length} dist)`;
              els.sidebarStateSelect.appendChild(opt);
            });
          }

          if (els.tableStateFilter) {
            els.tableStateFilter.innerHTML = '<option value="all">All States & UTs (36)</option>';
            states.forEach(st => {
              const opt = document.createElement('option');
              opt.value = st;
              opt.textContent = `${st} (${data.states[st].length})`;
              els.tableStateFilter.appendChild(opt);
            });
          }
        }
      })
      .catch(err => console.warn('Could not load states hierarchy:', err));
  }

  // Load all 782 districts for dropdown
  function loadDistrictsList() {
    fetch('/api/imd/districts')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.districts) {
          state.districtsList = data.districts;
          els.districtsDatalist.innerHTML = '';

          if (els.sidebarDistrictSelect) {
            els.sidebarDistrictSelect.innerHTML = '<option value="">-- Select District (782) --</option>';
          }

          data.districts.forEach(d => {
            const opt = document.createElement('option');
            opt.value = d.key;
            opt.textContent = `${d.district}, ${d.state} (Normal: ${d.annual_normal} mm)`;
            els.districtsDatalist.appendChild(opt);

            if (els.sidebarDistrictSelect) {
              const selOpt = document.createElement('option');
              selOpt.value = d.key;
              selOpt.textContent = `${d.district} (${d.state})`;
              els.sidebarDistrictSelect.appendChild(selOpt);
            }
          });

          // Default input to Pune
          els.districtSearchInput.value = 'Pune, Maharashtra';
          if (els.sidebarDistrictSelect) {
            els.sidebarDistrictSelect.value = 'Pune, Maharashtra';
          }
        }
      })
      .catch(err => console.warn('Could not load districts list:', err));
  }

  let districtSearchTimeout = null;

  // Load Real-time District Summary Table (782 Districts)
  function loadDistrictSummaryTable() {
    if (!els.districtsTableBody) return;

    const isSpiRange = (state.variable === 'spi' && state.spiSubMode === 'range' && state.spiStartDate && state.spiEndDate);

    if (els.districtsDateBadge) {
      els.districtsDateBadge.textContent = isSpiRange ? `${state.spiStartDate} to ${state.spiEndDate}` : state.currentDate;
    }

    const stateParam = encodeURIComponent(state.selectedStateFilter || 'all');
    const catParam = encodeURIComponent(state.selectedCategoryFilter || 'all');
    const qParam = encodeURIComponent(state.districtSearchQuery || '');
    const dateParam = encodeURIComponent(state.currentDate);

    const loadingMsg = isSpiRange
      ? `Loading 782 districts for Date Range ${state.spiStartDate} to ${state.spiEndDate}...`
      : `Loading 782 districts for ${state.currentDate}...`;
    els.districtsTableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:16px; color:var(--text-muted);"><i class="fa-solid fa-spinner fa-spin"></i> ${loadingMsg}</td></tr>`;

    let sumUrl = '';
    if (isSpiRange) {
      sumUrl = `/api/imd/district_summary?start_date=${encodeURIComponent(state.spiStartDate)}&end_date=${encodeURIComponent(state.spiEndDate)}&state=${stateParam}&category=${catParam}&search=${qParam}`;
    } else {
      sumUrl = `/api/imd/district_summary?date=${dateParam}&state=${stateParam}&category=${catParam}&search=${qParam}`;
    }

    fetch(sumUrl)
      .then(res => res.json())
      .then(data => {
        if (!data.success) {
          els.districtsTableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:16px; color:var(--accent-rose);">Error: ${data.error || 'Failed to load summary'}</td></tr>`;
          return;
        }

        const s = data.summary;
        if (els.kpiDistSevereDrought) els.kpiDistSevereDrought.innerHTML = `${s.severe_drought_count} <span style="font-size:10px; font-weight:normal;">(${s.severe_drought_pct}%)</span>`;
        if (els.kpiDistModDrought) els.kpiDistModDrought.innerHTML = `${s.moderate_drought_count} <span style="font-size:10px; font-weight:normal;">(${s.moderate_drought_pct}%)</span>`;
        if (els.kpiDistNormal) els.kpiDistNormal.innerHTML = `${s.normal_count} <span style="font-size:10px; font-weight:normal;">(${s.normal_pct}%)</span>`;
        if (els.kpiDistWet) els.kpiDistWet.innerHTML = `${s.wet_count} <span style="font-size:10px; font-weight:normal;">(${s.wet_pct}%)</span>`;
        if (els.districtsNatMeanRain) els.districtsNatMeanRain.textContent = `Mean: ${s.national_mean_daily_rainfall} mm`;
        if (els.districtsFilteredCount) els.districtsFilteredCount.textContent = data.total_filtered;

        // Populate SPI Calculation Windows
        if (data.spi_dates) {
          if (data.spi_dates.is_custom_range && data.spi_dates.range_window) {
            if (els.distSpi1Window) els.distSpi1Window.textContent = data.spi_dates.range_window;
            if (els.distSpi3Window) els.distSpi3Window.textContent = "Custom Date Range";
          } else {
            if (els.distSpi1Window) els.distSpi1Window.textContent = data.spi_dates.spi_1_window;
            if (els.distSpi3Window) els.distSpi3Window.textContent = data.spi_dates.spi_3_window;
          }
        }

        if (!data.districts || data.districts.length === 0) {
          els.districtsTableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:16px; color:var(--text-muted);">No districts matching criteria.</td></tr>`;
          return;
        }

        const rows = data.districts.map(d => {
          const depColor = d.daily_departure_pct >= 0 ? 'var(--accent-green)' : 'var(--accent-rose)';
          const depSign = d.daily_departure_pct >= 0 ? '+' : '';
          const safeBbox = JSON.stringify(d.bbox || []);
          return `
            <tr>
              <td style="color:var(--text-muted); font-family:var(--font-mono); font-size:10px;">${d.rank}</td>
              <td>
                <div style="font-weight:600; color:var(--text-primary);">${d.district}</div>
                <div style="font-size:9px; color:var(--text-muted);">${d.state}</div>
              </td>
              <td style="font-family:var(--font-mono); font-weight:700; color:var(--accent-blue);">
                ${d.daily_rainfall.toFixed(1)}
              </td>
              <td>
                <span style="font-family:var(--font-mono); font-size:10px; color:${depColor};">
                  ${depSign}${d.daily_departure_pct.toFixed(0)}%
                </span>
              </td>
              <td>
                <span class="dist-badge-sm" style="background:${d.spi_1_color}; color:#fff;" title="${d.spi_1_category} (SPI-1: ${d.spi_1})">
                  ${d.spi_1.toFixed(2)}
                </span>
              </td>
              <td>
                <div style="display:flex; gap:3px;">
                  <button class="btn-table-action btn-zoom-dist" data-lat="${d.center_lat}" data-lon="${d.center_lon}" data-name="${d.full_name}" data-bbox='${safeBbox}' title="Center Map on District">
                    <i class="fa-solid fa-map-pin"></i> Map
                  </button>
                  <button class="btn-table-action btn-hist-dist" data-name="${d.full_name}" title="1901-2025 Trend">
                    <i class="fa-solid fa-timeline"></i> 1901–2025
                  </button>
                </div>
              </td>
            </tr>
          `;
        }).join('');

        els.districtsTableBody.innerHTML = rows;

        // Wire zoom and history buttons
        els.districtsTableBody.querySelectorAll('.btn-zoom-dist').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const b = e.currentTarget;
            const lat = parseFloat(b.dataset.lat);
            const lon = parseFloat(b.dataset.lon);
            let bbox = [];
            try { bbox = JSON.parse(b.dataset.bbox); } catch(err) {}
            if (bbox && bbox.length === 4) {
              mapViewer.map.fitBounds([[bbox[0], bbox[1]], [bbox[2], bbox[3]]], { maxZoom: 9, padding: [20, 20] });
            } else {
              mapViewer.zoomTo(lat, lon, 8);
            }
            inspectPoint(lat, lon);
          });
        });

        els.districtsTableBody.querySelectorAll('.btn-hist-dist').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const name = e.currentTarget.dataset.name;
            openDistrictHistory(name);
          });
        });
      })
      .catch(err => {
        console.error('District summary fetch error:', err);
        els.districtsTableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:16px; color:var(--accent-rose);">Failed to load districts.</td></tr>`;
      });
  }

  // Check Sync Status
  function checkSyncStatus() {
    fetch('/api/imd/sync_status')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.sync_status) {
          const s = data.sync_status;
          if (els.headerSyncStatus) {
            const dateLabel = s.latest_date || (s.total_dates_available ? `${s.total_dates_available}d` : 'Active');
            els.headerSyncStatus.textContent = `Auto-Sync (${dateLabel})`;
          }
        }
      })
      .catch(err => console.warn('Could not check sync status:', err));
  }

  // Trigger Manual Unified Daily Sync (IMD Gridded + PMFBY + Live Parameters)
  function triggerManualSync() {
    if (els.syncIcon) els.syncIcon.classList.add('fa-spin');
    showLoading('Synchronizing all IMD Gridded Rainfall, SPI models, and PMFBY datasets...');

    fetch('/api/sync/all?force=true', { method: 'POST' })
      .then(res => res.json())
      .then(data => {
        if (els.syncIcon) els.syncIcon.classList.remove('fa-spin');
        hideLoading();
        if (data.success) {
          const newDates = (data.imd_sync && data.imd_sync.downloaded_dates) || [];
          const countStr = newDates.length > 0 ? ` (${newDates.length} new day(s) downloaded)` : ' (All data up-to-date)';
          alert(`Daily Synchronization Complete!\nLatest IMD Observation: ${data.latest_date}${countStr}\nPMFBY Status: ${data.pmfby_sync ? data.pmfby_sync.message : 'Synced'}`);
          // Refresh dates
          fetch('/api/dates')
            .then(r => r.json())
            .then(d => {
              state.dates = d.dates;
              els.timelineSlider.max = state.dates.length - 1;
              if (data.latest_date && state.dates.includes(data.latest_date)) {
                state.currentDateIndex = state.dates.indexOf(data.latest_date);
                state.currentDate = data.latest_date;
                els.timelineSlider.value = state.currentDateIndex;
                els.dateInput.value = state.currentDate;
              }
              loadGridData();
            });
          checkSyncStatus();
        } else {
          alert('Sync completed with warnings.');
        }
      })
      .catch(err => {
        if (els.syncIcon) els.syncIcon.classList.remove('fa-spin');
        hideLoading();
        console.error('Sync error:', err);
        alert('Failed to connect to data sources for synchronization.');
      });
  }

  // Load Grid from Server (Handles both Rainfall and SPI Modes)
  function loadGridData() {
    if (state.variable === 'spi') {
      // SPI Mode (Standard Timescale or Custom Date Range)
      let url = '';
      const isRange = (state.spiSubMode === 'range' && state.spiStartDate && state.spiEndDate);
      if (isRange) {
        showLoading(`Computing SPI Grid for Date Range ${state.spiStartDate} to ${state.spiEndDate}...`);
        url = `/api/imd/spi?start_date=${encodeURIComponent(state.spiStartDate)}&end_date=${encodeURIComponent(state.spiEndDate)}`;
      } else {
        const tsTitle = typeof state.spiTimescale === 'number' || /^\d+$/.test(state.spiTimescale) ? `SPI-${state.spiTimescale}` : state.spiTimescale.toUpperCase().replace('_', ' ');
        showLoading(`Computing ${tsTitle} Drought Index Grid for ${state.currentDate}...`);
        url = `/api/imd/spi?date=${encodeURIComponent(state.currentDate)}&timescale=${encodeURIComponent(state.spiTimescale)}`;
      }

      fetch(url)
        .then(res => res.json())
        .then(data => {
          hideLoading();
          if (!data.success) {
            alert(`SPI Error: ${data.error}`);
            return;
          }

          state.currentStats = data.stats;
          const tsScale = (isRange || data.is_custom_range) ? `range_${data.days_window}d` : state.spiTimescale;
          mapViewer.setSpiMode(true, tsScale);
          mapViewer.setGridData(data.grid, data.stats.drought_hotspots || []);

          updateHeaderAndHud(data);
          updateTopPointsTable(data.stats.drought_hotspots || [], true);
          updateAdvisories(data.stats.advisory || []);

          // Render SPI Category Distribution Chart
          charts.renderCategoryDistribution('distributionChart', data.stats.categories || []);

          // Update active point inspector
          const curPt = mapViewer.getRainfallAt(state.selectedPoint.lat, state.selectedPoint.lon);
          updateInspectorCard(state.selectedPoint.lat, state.selectedPoint.lon, curPt, state.currentDate);

          // Update districts table if active
          if (document.getElementById('tab-districts')?.classList.contains('active')) {
            loadDistrictSummaryTable();
          }
        })
        .catch(err => {
          console.error('SPI load error:', err);
          hideLoading();
        });

    } else {
      // Rainfall Mode
      showLoading(state.mode === 'daily' ? `Loading IMD Grid for ${state.currentDate}...` : 'Computing Cumulative Rainfall...');

      let url = '';
      if (state.mode === 'accumulate') {
        const p = els.accumPeriodSelect.value;
        if (p === 'custom') {
          const s = els.accumStartDate.value;
          const e = els.accumEndDate.value;
          url = `/api/grid?mode=accumulate&start_date=${s}&end_date=${e}`;
        } else {
          const days = parseInt(p, 10);
          url = `/api/grid?mode=accumulate&date=${state.currentDate}&accum_days=${days}`;
        }
      } else {
        url = `/api/grid?mode=daily&date=${state.currentDate}`;
      }

      fetch(url)
        .then(res => res.json())
        .then(data => {
          hideLoading();
          if (!data.success) {
            alert(`Error: ${data.error}`);
            return;
          }

          state.currentStats = data.stats;
          mapViewer.setSpiMode(false);
          mapViewer.setGridData(data.grid, data.stats.top_points);

          updateHeaderAndHud(data);
          updateTopPointsTable(data.stats.top_points, false);
          updateAdvisories(data.stats.agri_advisory);

          // Render Category Distribution Chart
          charts.renderCategoryDistribution('distributionChart', data.stats.categories);

          // Update active point inspector
          const curPt = mapViewer.getRainfallAt(state.selectedPoint.lat, state.selectedPoint.lon);
          updateInspectorCard(state.selectedPoint.lat, state.selectedPoint.lon, curPt, state.currentDate);

          // Update districts table if active
          if (document.getElementById('tab-districts')?.classList.contains('active')) {
            loadDistrictSummaryTable();
          }
        })
        .catch(err => {
          console.error('Grid load error:', err);
          hideLoading();
        });
    }
  }

  // Update Header KPIs and Floating HUD
  function updateHeaderAndHud(data) {
    const s = data.stats;

    if (state.variable === 'spi') {
      const calcDates = data.calculation_dates;
      const windowStr = (calcDates && calcDates.window_label)
        ? calcDates.window_label
        : `${data.start_date || state.currentDate} to ${data.end_date || state.currentDate} (${data.days_window || 90}d Window)`;

      const isCustom = Boolean(data.is_custom_range || state.spiSubMode === 'range');
      let titlePrefix = `SPI-${state.spiTimescale}`;
      let modeBadge = `WMO SPI-${state.spiTimescale}`;
      if (isCustom) {
        titlePrefix = `SPI Date Range (${data.days_window}d)`;
        modeBadge = `Custom Range (${data.days_window}d)`;
      } else if (state.spiTimescale === 'monsoon_2026') {
        titlePrefix = 'SPI SW Monsoon 2026';
        modeBadge = '2026 SW Monsoon';
      } else if (state.spiTimescale === 'post_monsoon_2026') {
        titlePrefix = 'SPI Post-Monsoon 2026';
        modeBadge = '2026 Post-Monsoon';
      } else if (state.spiTimescale === 'ytd_2026') {
        titlePrefix = 'SPI YTD 2026';
        modeBadge = '2026 Year-to-Date';
      }
      const dateText = `${titlePrefix} &bull; ${windowStr}`;

      if (els.spiWindowLabel) {
        els.spiWindowLabel.textContent = windowStr;
      }
      if (els.spiModeTypeBadge) {
        els.spiModeTypeBadge.textContent = modeBadge;
        els.spiModeTypeBadge.style.background = isCustom ? 'rgba(249, 115, 22, 0.25)' : 'rgba(56, 189, 248, 0.2)';
      }

      if (els.headerMaxRain) els.headerMaxRain.textContent = `+${s.max_spi}`;
      if (els.headerMeanRain) els.headerMeanRain.textContent = `${s.mean_spi}`;
      if (els.headerCoverage) els.headerCoverage.textContent = `${s.severe_drought_pct}%`;
      if (els.headerVolume) els.headerVolume.textContent = `${s.moderate_drought_pct}%`;

      els.hudDate.innerHTML = `<i class="fa-solid fa-droplet-slash"></i> ${dateText}`;
      els.hudMax.textContent = `Peak Drought: ${s.min_spi}`;
      els.hudMean.textContent = `Mean SPI: ${s.mean_spi}`;

    } else {
      const dateText = state.mode === 'daily' ? state.currentDate : `${data.start_date} to ${data.end_date} (${data.days_count} Days)`;
      if (els.headerMaxRain) els.headerMaxRain.textContent = `${s.max} mm`;
      if (els.headerMeanRain) els.headerMeanRain.textContent = `${s.mean} mm`;
      if (els.headerCoverage) els.headerCoverage.textContent = `${s.rain_coverage_pct}%`;
      if (els.headerVolume) els.headerVolume.textContent = `${s.total_volume_bcm} BCM`;

      els.hudDate.innerHTML = `<i class="fa-regular fa-calendar"></i> ${dateText}`;
      els.hudMax.textContent = `${s.max} mm (${s.max_location})`;
      els.hudMean.textContent = `${s.mean} mm`;
    }

    // Timeline Date Label & Slider
    els.timelineDateLabel.textContent = state.currentDate;
    els.timelineSlider.value = state.currentDateIndex;
    els.dateInput.value = state.currentDate;
  }

  // Inspect specific point with Point SPI and District integration
  function inspectPoint(lat, lon, ptData = null) {
    state.selectedPoint = { lat, lon };
    if (!ptData) {
      ptData = mapViewer.getRainfallAt(lat, lon);
    }
    updateInspectorCard(lat, lon, ptData, state.currentDate);

    // Fetch 7-day numerical weather forecast
    loadWeatherForecast(lat, lon);

    // Fetch multi-timescale SPI and district association from point API
    let pointUrl = `/api/imd/point_analysis?lat=${lat}&lon=${lon}&date=${encodeURIComponent(state.currentDate)}`;
    if (state.variable === 'spi' && state.spiSubMode === 'range' && state.spiStartDate && state.spiEndDate) {
      pointUrl += `&start_date=${encodeURIComponent(state.spiStartDate)}&end_date=${encodeURIComponent(state.spiEndDate)}`;
    }

    fetch(pointUrl)
      .then(res => res.json())
      .then(resData => {
        if (resData.success && resData.data) {
          const d = resData.data;
          els.inspectorLandmark.textContent = d.nearest_landmark;
          els.inspectorDistrictLabel.textContent = d.containing_district || '--';
          state.currentDistrict = d.containing_district || 'Pune, Maharashtra';

          // SPI Indicators & Calculation Date Ranges (WMO Operational Timescales)
          const setSpiBox = (valEl, dateEl, spiObj) => {
            if (!valEl || !spiObj) return;
            valEl.textContent = `${spiObj.value > 0 ? '+' : ''}${spiObj.value}`;
            valEl.style.color = spiObj.color;
            valEl.setAttribute('title', `${spiObj.category} (${spiObj.window_label || ''})`);
            if (dateEl) {
              dateEl.textContent = `${spiObj.start_date} to ${spiObj.end_date}`;
            }
          };

          setSpiBox(els.pointSpi1, els.pointSpi1Dates, d.spi_1);
          setSpiBox(els.pointSpi2, els.pointSpi2Dates, d.spi_2);
          setSpiBox(els.pointSpi3, els.pointSpi3Dates, d.spi_3);
          setSpiBox(els.pointSpi6, els.pointSpi6Dates, d.spi_6);
          setSpiBox(els.pointSpi12, els.pointSpi12Dates, d.spi_12);
          setSpiBox(els.pointSpi24, els.pointSpi24Dates, d.spi_24);

          // Custom Date Range SPI Card
          if (d.spi_range && els.pointSpiRangeCard) {
            els.pointSpiRangeCard.style.display = 'flex';
            if (els.pointSpiRangeVal) {
              els.pointSpiRangeVal.textContent = `${d.spi_range.value > 0 ? '+' : ''}${d.spi_range.value}`;
              els.pointSpiRangeVal.style.color = d.spi_range.color;
            }
            if (els.pointSpiRangeWindowLabel) {
              els.pointSpiRangeWindowLabel.textContent = d.spi_range.window_label;
            }
            if (els.pointSpiRangeBadge) {
              els.pointSpiRangeBadge.textContent = d.spi_range.category;
              els.pointSpiRangeBadge.style.background = d.spi_range.color;
              els.pointSpiRangeBadge.style.color = '#fff';
            }
          } else if (els.pointSpiRangeCard) {
            els.pointSpiRangeCard.style.display = 'none';
          }

          // Live Weather Parameters
          if (d.live_weather && els.liveWeatherCard) {
            const w = d.live_weather;
            state.liveWeather = w;
            if (els.liveWeatherCondition) els.liveWeatherCondition.textContent = w.condition || 'Clear';
            if (els.liveWeatherIcon) {
              els.liveWeatherIcon.className = `fa-solid ${w.icon || 'fa-sun'}`;
              els.liveWeatherIcon.style.color = w.color || '#facc15';
            }
            if (els.liveWeatherTemp) els.liveWeatherTemp.textContent = w.temperature !== undefined ? w.temperature : '--';
            if (els.liveWeatherFeels) els.liveWeatherFeels.textContent = w.apparent_temperature !== undefined ? w.apparent_temperature : '--';
            if (els.liveWeatherWind) els.liveWeatherWind.textContent = w.wind_speed !== undefined ? w.wind_speed : '--';
            if (els.liveWeatherCompass) els.liveWeatherCompass.textContent = w.wind_compass || '--';
            if (els.liveWeatherDeg) els.liveWeatherDeg.textContent = w.wind_direction !== undefined ? w.wind_direction : '--';
            if (els.liveWeatherGusts) els.liveWeatherGusts.textContent = w.wind_gusts !== undefined ? `${w.wind_gusts} km/h` : '--';
            if (els.liveWeatherHumidity) els.liveWeatherHumidity.textContent = w.humidity !== undefined ? w.humidity : '--';
            if (els.liveWeatherPressure) els.liveWeatherPressure.textContent = w.surface_pressure !== undefined ? w.surface_pressure : '--';
            if (els.liveWeatherClouds) els.liveWeatherClouds.textContent = w.cloud_cover !== undefined ? w.cloud_cover : '--';
            if (els.liveWeatherPrecip) els.liveWeatherPrecip.textContent = w.precipitation !== undefined ? w.precipitation : '0.0';
          } else if (els.liveWeatherCard) {
            fetchLiveWeather(lat, lon);
          }

          if (els.windySyncLabel) {
            const shortName = d.nearest_landmark ? d.nearest_landmark.split(',')[0].trim() : `${lat.toFixed(1)}°N`;
            els.windySyncLabel.textContent = shortName;
          }

          if (els.pointSpiRefDate) {
            const endDate = (d.spi_1 && d.spi_1.end_date) || state.currentDate;
            els.pointSpiRefDate.textContent = `Ending ${endDate} (WMO Operational: SPI-1, 2, 3, 6, 12, 24)`;
          }

          els.inspectorAccumVal.textContent = `${d.accumulated_rainfall} mm`;
          els.inspectorRainyDays.textContent = `${d.rainy_days} / ${d.total_days} Days`;

          // Render Point Time-series Chart
          charts.renderPointTimeSeries('timeSeriesChart', d.series, state.currentDate);
        }
      })
      .catch(err => console.warn('Point inspection fetch error:', err));
  }

  function updateInspectorCard(lat, lon, ptData, dateStr) {
    els.inspectorCoords.textContent = `${lat.toFixed(2)}°N, ${lon.toFixed(2)}°E`;
    if (ptData && ptData.value !== null) {
      if (state.variable === 'spi') {
        els.inspectorVal.textContent = ptData.value.toFixed(2);
        els.inspectorUnit.textContent = 'SPI';
        const cat = getSpiCategoryForVal(ptData.value);
        els.inspectorCategory.textContent = cat.name;
        els.inspectorCategory.style.backgroundColor = cat.color;
        els.inspectorCategory.style.color = cat.textColor;
      } else {
        els.inspectorVal.textContent = ptData.value.toFixed(1);
        els.inspectorUnit.textContent = 'mm';
        const cat = getCategoryForVal(ptData.value);
        els.inspectorCategory.textContent = cat.name;
        els.inspectorCategory.style.backgroundColor = cat.color;
        els.inspectorCategory.style.color = cat.textColor;
      }
    } else {
      els.inspectorVal.textContent = '0.0';
      els.inspectorCategory.textContent = 'Sea / Out of Bounds';
      els.inspectorCategory.style.backgroundColor = '#334155';
      els.inspectorCategory.style.color = '#fff';
    }
  }

  function getCategoryForVal(v) {
    if (v < 0.1) return { name: "No Rain", color: "#f8fafc", textColor: "#475569" };
    if (v < 2.5) return { name: "Very Light Rain", color: "#bae6fd", textColor: "#0369a1" };
    if (v < 15.6) return { name: "Light Rain", color: "#38bdf8", textColor: "#075985" };
    if (v < 64.5) return { name: "Moderate Rain", color: "#4ade80", textColor: "#15803d" };
    if (v < 115.6) return { name: "Heavy Rain", color: "#facc15", textColor: "#854d0e" };
    if (v < 204.5) return { name: "Very Heavy Rain", color: "#fb923c", textColor: "#9a3412" };
    return { name: "Extremely Heavy Rain", color: "#dc2626", textColor: "#ffffff" };
  }

  function getSpiCategoryForVal(v) {
    if (v <= -2.0) return { name: "Extremely Dry (Severe Drought)", color: "#dc2626", textColor: "#ffffff" };
    if (v <= -1.5) return { name: "Severely Dry (Moderate Drought)", color: "#f97316", textColor: "#ffffff" };
    if (v <= -1.0) return { name: "Moderately Dry (Mild Drought)", color: "#eab308", textColor: "#713f12" };
    if (v < 1.0)   return { name: "Near Normal", color: "#22c55e", textColor: "#ffffff" };
    if (v < 1.5)   return { name: "Moderately Wet", color: "#06b6d4", textColor: "#ffffff" };
    if (v < 2.0)   return { name: "Very Wet", color: "#2563eb", textColor: "#ffffff" };
    return { name: "Extremely Wet", color: "#1e3a8a", textColor: "#ffffff" };
  }

  // Update Top Points Table (Rainfall Hotspots vs Drought Hotspots)
  function updateTopPointsTable(topPoints, isSpi = false) {
    els.topPointsBody.innerHTML = '';
    if (!topPoints || topPoints.length === 0) {
      els.topPointsBody.innerHTML = `<tr><td colspan="4" style="text-align:center;color:#64748b;">No ${isSpi ? 'drought' : 'high rainfall'} centers identified.</td></tr>`;
      return;
    }

    topPoints.forEach((pt, i) => {
      const tr = document.createElement('tr');
      const valStr = isSpi ? `SPI: ${pt.spi > 0 ? '+' : ''}${pt.spi}` : `${pt.rainfall} mm`;
      const valColor = isSpi ? (pt.color || '#f97316') : (pt.rainfall >= 115.6 ? '#ef4444' : '#38bdf8');

      tr.innerHTML = `
        <td style="font-weight:700;">#${i + 1}</td>
        <td>
          <div style="font-weight:600;color:var(--text-primary);">${pt.location}</div>
          <div style="font-size:10px;color:var(--text-muted);font-family:var(--font-mono);">${pt.lat}°N, ${pt.lon}°E</div>
        </td>
        <td>
          <span style="font-weight:700;font-family:var(--font-mono);color:${valColor};">${valStr}</span>
          <div style="font-size:10px;color:var(--text-muted);">${pt.category || pt.badge || ''}</div>
        </td>
        <td>
          <button class="btn-zoom" data-lat="${pt.lat}" data-lon="${pt.lon}">
            <i class="fa-solid fa-crosshairs"></i> Zoom
          </button>
        </td>
      `;
      els.topPointsBody.appendChild(tr);
    });

    els.topPointsBody.querySelectorAll('.btn-zoom').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const lat = parseFloat(e.currentTarget.getAttribute('data-lat'));
        const lon = parseFloat(e.currentTarget.getAttribute('data-lon'));
        mapViewer.zoomTo(lat, lon, 8);
        inspectPoint(lat, lon);
      });
    });
  }

  // Update AgriDSS Advisories
  function updateAdvisories(advisories) {
    els.advisoryContainer.innerHTML = '';
    if (!advisories || advisories.length === 0) return;

    advisories.forEach(adv => {
      const card = document.createElement('div');
      card.className = `advisory-card ${adv.level}`;
      card.innerHTML = `
        <div class="advisory-title">
          <span>${adv.title}</span>
          ${adv.badge ? `<span class="advisory-badge" style="background:rgba(255,255,255,0.15);">${adv.badge}</span>` : ''}
        </div>
        <div class="advisory-desc">${adv.message}</div>
      `;
      els.advisoryContainer.appendChild(card);
    });
  }

  // =========================================================================
  // Historical IMD District Analysis Modal (1901-2025)
  // =========================================================================
  function openDistrictHistory(districtQuery) {
    if (!districtQuery) return;
    showLoading(`Loading 1901–2025 Historical Baseline for ${districtQuery}...`);

    fetch(`/api/imd/district_analysis?district=${encodeURIComponent(districtQuery)}`)
      .then(res => res.json())
      .then(data => {
        hideLoading();
        if (!data.success || !data.district) {
          alert(`District "${districtQuery}" not found in historical database.`);
          return;
        }

        const d = data.district;
        state.currentDistrictRecord = d;

        // Populate Header & Badges
        els.modalDistrictTitle.textContent = `${d.district_name}, ${d.state_name}`;
        els.modalSubdivisionBadge.textContent = d.subdivision;

        // Populate KPIs
        els.kpiAnnualNormal.textContent = `${d.annual_normal_mm} mm`;
        els.kpiMonsoonNormal.textContent = `${d.monsoon_normal_mm} mm`;
        els.kpiPeakYear.textContent = `${d.peak_rainfall_year} (${d.peak_rainfall_mm} mm)`;
        els.kpiDriestYear.textContent = `${d.lowest_rainfall_year} (${d.lowest_rainfall_mm} mm)`;
        els.kpiTotalDroughts.textContent = `${d.drought_statistics.total_drought_years} (${d.drought_statistics.drought_frequency_pct}%)`;
        els.kpiReturnPeriod.textContent = `1 in ${d.drought_statistics.severe_drought_return_period_years} yrs`;

        // Display Modal
        els.districtHistoryModal.style.display = 'flex';

        // Render Charts after modal becomes visible
        setTimeout(() => {
          charts.renderHistoricalTrendChart('historicalTrendCanvas', d.timeline, d.annual_normal_mm);
          charts.renderHistoricalSpiChart('historicalSpiCanvas', d.timeline);
          charts.renderMonthlyNormalsChart('historicalMonthlyCanvas', d.monthly_normals);
        }, 80);
      })
      .catch(err => {
        console.error('District history load error:', err);
        hideLoading();
        alert('Failed to load district historical dataset.');
      });
  }

  // Export District 1901-2025 CSV
  function exportDistrictCsv(d) {
    if (!d || !d.timeline) return;

    let csv = `Year,District,State,Subdivision,Annual_Rainfall_mm,Monsoon_Rainfall_mm,Climatological_Normal_mm,Departure_Pct,SPI_12_Annual,SPI_3_Monsoon,WMO_Category\n`;
    d.timeline.forEach(t => {
      csv += `${t.year},"${d.district_name}","${d.state_name}","${d.subdivision}",${t.annual_rainfall},${t.monsoon_rainfall},${d.annual_normal_mm},${t.departure_pct},${t.spi_12},${t.spi_3},"${t.category}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `IMD_Rainfall_1901_2025_${d.district_name}_${d.state_name}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // =========================================================================
  // Playback Animation Engine
  // =========================================================================
  function startPlayback() {
    if (state.isPlaying) return;
    state.isPlaying = true;
    els.playIcon.className = 'fa-solid fa-pause';
    els.playPauseBtn.setAttribute('title', 'Pause Animation');

    state.playInterval = setInterval(() => {
      state.currentDateIndex = (state.currentDateIndex + 1) % state.dates.length;
      state.currentDate = state.dates[state.currentDateIndex];
      els.timelineSlider.value = state.currentDateIndex;
      loadGridData();
    }, state.playbackSpeed);
  }

  function pausePlayback() {
    if (!state.isPlaying) return;
    state.isPlaying = false;
    clearInterval(state.playInterval);
    state.playInterval = null;
    els.playIcon.className = 'fa-solid fa-play';
    els.playPauseBtn.setAttribute('title', 'Play Daily Animation');
  }

  function togglePlayback() {
    if (state.isPlaying) {
      pausePlayback();
    } else {
      startPlayback();
    }
  }

  // =========================================================================
  // Event Handlers & Controls
  // =========================================================================
  // Variable Toggle: Rainfall vs SPI
  els.varRainfallBtn.addEventListener('click', () => {
    if (state.variable === 'rainfall') return;
    state.variable = 'rainfall';
    els.varRainfallBtn.classList.add('active');
    els.varSpiBtn.classList.remove('active');
    els.activeVariableBadge.textContent = 'Precipitation';
    els.activeVariableBadge.style.background = 'var(--accent-blue)';
    els.spiTimescaleGroup.style.display = 'none';

    // Toggle Legend
    els.legendTitleMain.textContent = 'IMD Rainfall Intensity';
    els.legendTitleSub.textContent = '24h (mm)';
    els.rainfallLegendScale.style.display = 'flex';
    els.spiLegendScale.style.display = 'none';

    loadGridData();
  });

  els.varSpiBtn.addEventListener('click', () => {
    if (state.variable === 'spi') return;
    state.variable = 'spi';
    els.varSpiBtn.classList.add('active');
    els.varRainfallBtn.classList.remove('active');
    const tsBadge = typeof state.spiTimescale === 'number' || /^\d+$/.test(state.spiTimescale) ? `SPI-${state.spiTimescale} Drought` : state.spiTimescale.toUpperCase().replace('_', ' ');
    els.activeVariableBadge.textContent = tsBadge;
    els.activeVariableBadge.style.background = '#f97316';
    els.spiTimescaleGroup.style.display = 'flex';

    // Toggle Legend
    els.legendTitleMain.textContent = 'WMO SPI Drought Severity';
    els.legendTitleSub.textContent = typeof state.spiTimescale === 'number' || /^\d+$/.test(state.spiTimescale) ? `SPI-${state.spiTimescale} Scale` : state.spiTimescale;
    els.rainfallLegendScale.style.display = 'none';
    els.spiLegendScale.style.display = 'flex';

    loadGridData();
  });

  // SPI Timescale Selection (Supports WMO Operational Scales & 2026 Seasons)
  els.spiTimescaleSelect.addEventListener('change', (e) => {
    const val = e.target.value;
    state.spiTimescale = /^\d+$/.test(val) ? parseInt(val, 10) : val;
    let badgeText = `SPI-${state.spiTimescale} Drought`;
    let legendSub = `SPI-${state.spiTimescale} Scale`;
    if (val === 'monsoon_2026') {
      badgeText = 'SPI SW Monsoon 2026';
      legendSub = '2026 Monsoon (Jun–Sep)';
    } else if (val === 'post_monsoon_2026') {
      badgeText = 'SPI Post-Monsoon 2026';
      legendSub = '2026 Post-Monsoon (Oct)';
    } else if (val === 'ytd_2026') {
      badgeText = 'SPI YTD 2026';
      legendSub = '2026 YTD (Jan–Oct)';
    }
    els.activeVariableBadge.textContent = badgeText;
    els.legendTitleSub.textContent = legendSub;
    loadGridData();
  });

  // SPI Sub-Mode Selection: Timescale vs Custom Date Range
  if (els.btnSpiSubTimescale && els.btnSpiSubRange) {
    els.btnSpiSubTimescale.addEventListener('click', () => {
      if (state.spiSubMode === 'timescale') return;
      state.spiSubMode = 'timescale';
      els.btnSpiSubTimescale.classList.add('active');
      els.btnSpiSubRange.classList.remove('active');
      if (els.spiTimescaleSelectWrapper) els.spiTimescaleSelectWrapper.style.display = 'block';
      if (els.spiCustomRangeControls) els.spiCustomRangeControls.style.display = 'none';
      els.activeVariableBadge.textContent = `SPI-${state.spiTimescale} Drought`;
      els.legendTitleSub.textContent = `SPI-${state.spiTimescale} Scale`;
      loadGridData();
    });

    els.btnSpiSubRange.addEventListener('click', () => {
      if (state.spiSubMode === 'range') return;
      state.spiSubMode = 'range';
      els.btnSpiSubRange.classList.add('active');
      els.btnSpiSubTimescale.classList.remove('active');
      if (els.spiTimescaleSelectWrapper) els.spiTimescaleSelectWrapper.style.display = 'none';
      if (els.spiCustomRangeControls) els.spiCustomRangeControls.style.display = 'flex';
      els.activeVariableBadge.textContent = 'SPI Date Range';
      els.legendTitleSub.textContent = 'Custom Range Scale';

      if (els.spiStartDate && (!els.spiStartDate.value || !els.spiEndDate.value)) {
        els.spiEndDate.value = state.currentDate || '2026-10-30';
        const d = new Date(els.spiEndDate.value);
        d.setDate(d.getDate() - 89);
        els.spiStartDate.value = d.toISOString().split('T')[0];
      }
      state.spiStartDate = els.spiStartDate ? els.spiStartDate.value : null;
      state.spiEndDate = els.spiEndDate ? els.spiEndDate.value : null;
      loadGridData();
    });
  }

  function normalizeDateInput(str) {
    if (!str) return '';
    str = str.trim();
    if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(str)) {
      const parts = str.split('-');
      return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
    }
    const m = str.match(/^(\d{1,2})[/\-\.](\d{1,2})[/\-\.](\d{4})$/);
    if (m) {
      const d = m[1].padStart(2, '0');
      const mo = m[2].padStart(2, '0');
      const yr = m[3];
      return `${yr}-${mo}-${d}`;
    }
    return str;
  }

  // Calculate SPI for Date Range button
  if (els.btnApplySpiRange) {
    els.btnApplySpiRange.addEventListener('click', () => {
      let sDate = els.spiStartDate ? els.spiStartDate.value : '';
      let eDate = els.spiEndDate ? els.spiEndDate.value : '';
      sDate = normalizeDateInput(sDate);
      eDate = normalizeDateInput(eDate);
      if (els.spiStartDate) els.spiStartDate.value = sDate;
      if (els.spiEndDate) els.spiEndDate.value = eDate;

      if (!sDate || !eDate) {
        alert('Please choose both Start Date and End Date for SPI calculation.');
        return;
      }
      if (sDate > eDate) {
        alert('Start Date must be before or equal to End Date.');
        return;
      }
      state.spiStartDate = sDate;
      state.spiEndDate = eDate;
      state.spiSubMode = 'range';
      loadGridData();
    });
  }

  // Quick SPI Date Presets Chips
  document.querySelectorAll('[data-spi-preset]').forEach(chip => {
    chip.addEventListener('click', (e) => {
      const preset = e.currentTarget.getAttribute('data-spi-preset');
      document.querySelectorAll('[data-spi-preset]').forEach(c => c.classList.remove('active'));
      e.currentTarget.classList.add('active');

      const refDate = state.currentDate || '2026-10-30';
      const dtRef = new Date(refDate);

      let sStr = '';
      let eStr = refDate;

      if (preset === 'monsoon') {
        const yr = dtRef.getFullYear();
        sStr = `${yr}-06-01`;
        eStr = `${yr}-09-30`;
      } else if (preset === 'oct_date') {
        const yr = dtRef.getFullYear();
        sStr = `${yr}-10-01`;
        eStr = refDate;
      } else if (preset === '30d') {
        const d = new Date(refDate);
        d.setDate(d.getDate() - 29);
        sStr = d.toISOString().split('T')[0];
      } else if (preset === '60d') {
        const d = new Date(refDate);
        d.setDate(d.getDate() - 59);
        sStr = d.toISOString().split('T')[0];
      } else if (preset === '90d') {
        const d = new Date(refDate);
        d.setDate(d.getDate() - 89);
        sStr = d.toISOString().split('T')[0];
      } else if (preset === '180d') {
        const d = new Date(refDate);
        d.setDate(d.getDate() - 179);
        sStr = d.toISOString().split('T')[0];
      }

      if (els.spiStartDate) els.spiStartDate.value = sStr;
      if (els.spiEndDate) els.spiEndDate.value = eStr;
      state.spiStartDate = sStr;
      state.spiEndDate = eStr;
      state.spiSubMode = 'range';

      if (els.btnSpiSubRange) {
        els.btnSpiSubRange.classList.add('active');
        els.btnSpiSubTimescale.classList.remove('active');
        if (els.spiTimescaleSelectWrapper) els.spiTimescaleSelectWrapper.style.display = 'none';
        if (els.spiCustomRangeControls) els.spiCustomRangeControls.style.display = 'flex';
      }

      loadGridData();
    });
  });

  // District Search & Analyze Trigger
  els.btnAnalyzeDistrict.addEventListener('click', () => {
    const q = els.districtSearchInput.value.trim();
    if (q) openDistrictHistory(q);
  });

  els.districtSearchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const q = els.districtSearchInput.value.trim();
      if (q) openDistrictHistory(q);
    }
  });

  // Header History Trigger
  els.btnHeaderHistory.addEventListener('click', () => {
    openDistrictHistory(state.currentDistrict || 'Pune, Maharashtra');
  });

  // Header Sync Trigger
  els.btnHeaderSync.addEventListener('click', (e) => {
    e.stopPropagation();
    triggerManualSync();
  });

  // Point Probe District History Trigger
  els.btnDistrictHistoryFromProbe.addEventListener('click', () => {
    openDistrictHistory(state.currentDistrict || 'Pune, Maharashtra');
  });

  // Close District Modal
  els.closeDistrictModalBtn.addEventListener('click', () => {
    els.districtHistoryModal.style.display = 'none';
  });
  els.districtHistoryModal.addEventListener('click', (e) => {
    if (e.target === els.districtHistoryModal) {
      els.districtHistoryModal.style.display = 'none';
    }
  });

  // Export District CSV Trigger
  els.btnExportDistrictCsv.addEventListener('click', () => {
    if (state.currentDistrictRecord) {
      exportDistrictCsv(state.currentDistrictRecord);
    }
  });

  // Play / Pause / Step Controls
  els.playPauseBtn.addEventListener('click', togglePlayback);

  els.stepPrevBtn.addEventListener('click', () => {
    pausePlayback();
    if (state.currentDateIndex > 0) {
      state.currentDateIndex--;
      state.currentDate = state.dates[state.currentDateIndex];
      loadGridData();
    }
  });

  els.stepNextBtn.addEventListener('click', () => {
    pausePlayback();
    if (state.currentDateIndex < state.dates.length - 1) {
      state.currentDateIndex++;
      state.currentDate = state.dates[state.currentDateIndex];
      loadGridData();
    }
  });

  els.speedSelect.addEventListener('change', (e) => {
    state.playbackSpeed = parseInt(e.target.value, 10);
    if (state.isPlaying) {
      pausePlayback();
      startPlayback();
    }
  });

  els.timelineSlider.addEventListener('input', (e) => {
    pausePlayback();
    const idx = parseInt(e.target.value, 10);
    if (idx >= 0 && idx < state.dates.length) {
      state.currentDateIndex = idx;
      state.currentDate = state.dates[idx];
      els.timelineDateLabel.textContent = state.currentDate;
      loadGridData();
    }
  });

  els.dateInput.addEventListener('change', (e) => {
    pausePlayback();
    const val = e.target.value;
    const idx = state.dates.indexOf(val);
    if (idx !== -1) {
      state.currentDateIndex = idx;
      state.currentDate = val;
      loadGridData();
    } else {
      if (confirm(`Date ${val} is not currently cached locally. Would you like to fetch it from IMD Pune archives?`)) {
        els.fetchDateInput.value = val;
        fetchFromImd(val);
      }
    }
  });

  // Daily vs Accumulate Mode
  els.modeDailyBtn.addEventListener('click', () => {
    if (state.mode === 'daily') return;
    state.mode = 'daily';
    els.modeDailyBtn.classList.add('active');
    els.modeAccumBtn.classList.remove('active');
    els.accumControls.style.display = 'none';
    loadGridData();
  });

  els.modeAccumBtn.addEventListener('click', () => {
    if (state.mode === 'accumulate') return;
    state.mode = 'accumulate';
    els.modeAccumBtn.classList.add('active');
    els.modeDailyBtn.classList.remove('active');
    els.accumControls.style.display = 'flex';
    pausePlayback();
    loadGridData();
  });

  els.accumPeriodSelect.addEventListener('change', (e) => {
    if (e.target.value === 'custom') {
      els.customRangeGroup.style.display = 'flex';
    } else {
      els.customRangeGroup.style.display = 'none';
      loadGridData();
    }
  });

  els.applyAccumBtn.addEventListener('click', () => {
    loadGridData();
  });

  // Preset Chips
  els.presetChips.forEach(chip => {
    chip.addEventListener('click', (e) => {
      pausePlayback();
      els.presetChips.forEach(c => c.classList.remove('active'));
      e.currentTarget.classList.add('active');

      const presetDate = e.currentTarget.getAttribute('data-date');
      const idx = state.dates.indexOf(presetDate);
      if (idx !== -1) {
        state.currentDateIndex = idx;
        state.currentDate = presetDate;
        loadGridData();
      } else {
        fetchFromImd(presetDate);
      }
    });
  });

  // Visualization settings
  if (els.basemapSelect) {
    els.basemapSelect.addEventListener('change', (e) => mapViewer.setBasemap(e.target.value));
  }
  mapViewer.map.on('baselayerchange', (e) => {
    if (els.basemapSelect) {
      if (e.name.includes('Voyager')) els.basemapSelect.value = 'voyager';
      else if (e.name.includes('Dark')) els.basemapSelect.value = 'dark';
      else if (e.name.includes('Positron')) els.basemapSelect.value = 'positron';
      else if (e.name.includes('OpenStreetMap')) els.basemapSelect.value = 'osm';
      else if (e.name.includes('Satellite')) els.basemapSelect.value = 'satellite';
    }
  });

  els.paletteSelect.addEventListener('change', (e) => mapViewer.setPalette(e.target.value));
  els.renderModeSelect.addEventListener('change', (e) => mapViewer.setRenderMode(e.target.value));
  els.opacitySlider.addEventListener('input', (e) => {
    els.opacityValue.textContent = `${Math.round(e.target.value * 100)}%`;
    mapViewer.setOpacity(e.target.value);
  });
  els.toggleStatesSwitch.addEventListener('change', (e) => mapViewer.toggleStates(e.target.checked));
  els.toggleHotspotsSwitch.addEventListener('change', (e) => mapViewer.toggleHotspots(e.target.checked));
  els.btnResetView.addEventListener('click', () => mapViewer.resetView());

  // On-demand IMD Fetcher
  function fetchFromImd(targetDate) {
    if (!targetDate) return;
    els.fetchStatus.textContent = `Connecting to IMD Pune for ${targetDate}...`;
    els.fetchStatus.style.color = 'var(--accent-blue)';
    els.btnFetchImd.disabled = true;

    fetch('/api/fetch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ date: targetDate })
    })
      .then(res => res.json())
      .then(data => {
        els.btnFetchImd.disabled = false;
        if (data.success) {
          els.fetchStatus.textContent = `✓ Fetched ${targetDate} successfully!`;
          els.fetchStatus.style.color = 'var(--accent-green)';
          fetch('/api/dates')
            .then(r => r.json())
            .then(d => {
              state.dates = d.dates;
              els.timelineSlider.max = state.dates.length - 1;
              state.currentDateIndex = state.dates.indexOf(targetDate);
              state.currentDate = targetDate;
              loadGridData();
            });
        } else {
          els.fetchStatus.textContent = `✗ ${data.error}`;
          els.fetchStatus.style.color = '#ef4444';
        }
      })
      .catch(err => {
        els.btnFetchImd.disabled = false;
        els.fetchStatus.textContent = `✗ Request failed: ${err.message}`;
        els.fetchStatus.style.color = '#ef4444';
      });
  }

  els.btnFetchImd.addEventListener('click', () => {
    fetchFromImd(els.fetchDateInput.value.trim());
  });

  // Upload .GRD File
  els.dropzone.addEventListener('click', () => els.fileInput.click());

  els.fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    els.uploadStatus.textContent = `Uploading ${file.name}...`;
    els.uploadStatus.style.color = 'var(--accent-blue)';

    fetch('/api/upload', {
      method: 'POST',
      body: formData
    })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          els.uploadStatus.textContent = `✓ Loaded ${file.name}`;
          els.uploadStatus.style.color = 'var(--accent-green)';
          initApp();
        } else {
          els.uploadStatus.textContent = `✗ ${data.error}`;
          els.uploadStatus.style.color = '#ef4444';
        }
      })
      .catch(err => {
        els.uploadStatus.textContent = `✗ Upload failed: ${err.message}`;
        els.uploadStatus.style.color = '#ef4444';
      });
  });

  // Export Buttons
  els.btnExportCsv.addEventListener('click', () => {
    let url = `/api/export/csv?date=${state.currentDate}&mode=${state.mode}`;
    if (state.mode === 'accumulate') {
      const p = els.accumPeriodSelect.value;
      if (p === 'custom') {
        url += `&start_date=${els.accumStartDate.value}&end_date=${els.accumEndDate.value}`;
      } else {
        const days = parseInt(p, 10);
        const dt = new Date(state.currentDate);
        dt.setDate(dt.getDate() - days + 1);
        url += `&start_date=${dt.toISOString().split('T')[0]}&end_date=${state.currentDate}`;
      }
    }
    window.location.href = url;
  });

  els.btnExportGeoJson.addEventListener('click', () => {
    window.location.href = `/api/export/geojson?date=${state.currentDate}`;
  });

  // Right Sidebar Tabs
  function switchTab(targetId) {
    els.tabBtns.forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-target') === targetId);
    });
    els.tabPanes.forEach(pane => {
      pane.classList.toggle('active', pane.id === targetId);
    });

    if (targetId === 'tab-districts') {
      if (els.rightSidebar) els.rightSidebar.classList.add('expanded-districts');
      loadDistrictSummaryTable();
    } else {
      if (els.rightSidebar) els.rightSidebar.classList.remove('expanded-districts');
    }
  }

  els.tabBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const targetId = e.currentTarget.getAttribute('data-target');
      switchTab(targetId);
    });
  });

  // Whole Districts Filter & Search Listeners
  if (els.sidebarStateSelect) {
    els.sidebarStateSelect.addEventListener('change', (e) => {
      const selectedState = e.target.value;
      if (!els.sidebarDistrictSelect) return;

      els.sidebarDistrictSelect.innerHTML = '<option value="">-- Select District --</option>';
      if (!selectedState) {
        state.districtsList.forEach(d => {
          const opt = document.createElement('option');
          opt.value = d.key;
          opt.textContent = `${d.district} (${d.state})`;
          els.sidebarDistrictSelect.appendChild(opt);
        });
      } else {
        const dists = state.statesHierarchy[selectedState] || [];
        dists.forEach(dName => {
          const opt = document.createElement('option');
          opt.value = `${dName}, ${selectedState}`;
          opt.textContent = dName;
          els.sidebarDistrictSelect.appendChild(opt);
        });
      }
    });
  }

  if (els.sidebarDistrictSelect) {
    els.sidebarDistrictSelect.addEventListener('change', (e) => {
      const val = e.target.value;
      if (val) {
        els.districtSearchInput.value = val;
        const found = state.districtsList.find(d => d.key === val || d.district === val);
        if (found) {
          mapViewer.zoomTo(found.center_lat, found.center_lon, 8);
          inspectPoint(found.center_lat, found.center_lon);
        }
      }
    });
  }

  if (els.btnOpenDistrictsTable) {
    els.btnOpenDistrictsTable.addEventListener('click', () => {
      els.rightSidebar.classList.remove('collapsed-right');
      switchTab('tab-districts');
    });
  }

  if (els.tableStateFilter) {
    els.tableStateFilter.addEventListener('change', (e) => {
      state.selectedStateFilter = e.target.value;
      loadDistrictSummaryTable();
    });
  }

  if (els.tableCategoryFilter) {
    els.tableCategoryFilter.addEventListener('change', (e) => {
      state.selectedCategoryFilter = e.target.value;
      if (els.filterChips) {
        els.filterChips.forEach(c => {
          c.classList.toggle('active', c.getAttribute('data-category') === state.selectedCategoryFilter);
        });
      }
      loadDistrictSummaryTable();
    });
  }

  if (els.filterChips) {
    els.filterChips.forEach(chip => {
      chip.addEventListener('click', (e) => {
        const cat = e.currentTarget.getAttribute('data-category');
        state.selectedCategoryFilter = cat;
        if (els.tableCategoryFilter) els.tableCategoryFilter.value = cat;
        els.filterChips.forEach(c => c.classList.remove('active'));
        e.currentTarget.classList.add('active');
        loadDistrictSummaryTable();
      });
    });
  }

  if (els.tableDistrictSearch) {
    els.tableDistrictSearch.addEventListener('input', (e) => {
      clearTimeout(districtSearchTimeout);
      state.districtSearchQuery = e.target.value.trim();
      districtSearchTimeout = setTimeout(() => {
        loadDistrictSummaryTable();
      }, 250);
    });
  }

  if (els.btnRefreshDistrictSummary) {
    els.btnRefreshDistrictSummary.addEventListener('click', () => {
      loadDistrictSummaryTable();
    });
  }

  // Theme Toggle
  els.themeToggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    els.themeToggleBtn.innerHTML = isLight ? '<i class="fa-solid fa-moon"></i>' : '<i class="fa-solid fa-sun"></i>';
    state.theme = isLight ? 'light' : 'dark';
  });

  // Info Modal
  els.infoModalBtn.addEventListener('click', () => els.infoModal.style.display = 'flex');
  els.closeModalBtn.addEventListener('click', () => els.infoModal.style.display = 'none');
  els.infoModal.addEventListener('click', (e) => {
    if (e.target === els.infoModal) els.infoModal.style.display = 'none';
  });

  // Sidebar Toggles
  els.toggleLeftSidebar.addEventListener('click', () => {
    els.leftSidebar.classList.toggle('collapsed-left');
  });

  els.toggleRightSidebar.addEventListener('click', () => {
    els.rightSidebar.classList.toggle('collapsed-right');
  });

  // ========================================================================
  // Windy Live Weather Engine Controller & Live Weather Integration
  // ========================================================================
  function updateWindyIframe(lat, lon, zoom, overlay) {
    const latVal = (lat !== undefined && lat !== null) ? Number(lat).toFixed(4) : state.windyCenter.lat.toFixed(4);
    const lonVal = (lon !== undefined && lon !== null) ? Number(lon).toFixed(4) : state.windyCenter.lon.toFixed(4);
    const zoomVal = zoom || state.windyZoom || 5;
    const overlayVal = overlay || state.windyOverlay || 'wind';

    const url = `https://embed.windy.com/embed.html?lat=${latVal}&lon=${lonVal}&detailLat=${latVal}&detailLon=${lonVal}&width=100%&height=100%&zoom=${zoomVal}&level=surface&overlay=${overlayVal}&product=ecmwf&menu=&message=true&marker=true&calendar=now&pressure=true&type=map&location=coordinates&detail=true&metricWind=km%2Fh&metricTemp=%C2%B0C&radarRange=-1`;

    if (els.windyIframe) {
      els.windyIframe.src = url;
    }
    if (els.btnWindyExternal) {
      els.btnWindyExternal.href = `https://www.windy.com/?${latVal},${lonVal},${zoomVal}`;
    }
    state.windyCenter = { lat: Number(latVal), lon: Number(lonVal) };
    state.windyZoom = zoomVal;
    state.windyOverlay = overlayVal;
  }

  function setViewMode(mode) {
    state.viewMode = mode;
    if (mode === 'windy') {
      if (els.windyContainer) els.windyContainer.style.display = 'flex';
      if (els.mapForecastBar) els.mapForecastBar.style.display = 'none';
      if (els.btnViewWindy) els.btnViewWindy.classList.add('active');
      if (els.btnViewImd) els.btnViewImd.classList.remove('active');
      if (els.btnViewForecast) els.btnViewForecast.classList.remove('active');
      if (els.btnHeaderWindy) {
        els.btnHeaderWindy.style.background = 'linear-gradient(135deg, #10b981, #059669)';
        els.btnHeaderWindy.innerHTML = '<i class="fa-solid fa-cloud-showers-heavy"></i> IMD Map View';
      }
      const curLat = state.selectedPoint ? state.selectedPoint.lat : 20.5937;
      const curLon = state.selectedPoint ? state.selectedPoint.lon : 78.9629;
      if (!els.windyIframe.src || els.windyIframe.src === 'about:blank' || els.windyIframe.src === window.location.href) {
        updateWindyIframe(curLat, curLon, 6, state.windyOverlay);
      }
    } else if (mode === 'forecast') {
      if (els.windyContainer) els.windyContainer.style.display = 'none';
      if (els.mapForecastBar) els.mapForecastBar.style.display = 'block';
      if (els.btnViewForecast) els.btnViewForecast.classList.add('active');
      if (els.btnViewImd) els.btnViewImd.classList.remove('active');
      if (els.btnViewWindy) els.btnViewWindy.classList.remove('active');
      if (els.btnHeaderWindy) {
        els.btnHeaderWindy.style.background = 'linear-gradient(135deg, #0284c7, #0369a1)';
        els.btnHeaderWindy.innerHTML = '<i class="fa-solid fa-wind"></i> Windy Weather';
      }
      const curLat = state.selectedPoint ? state.selectedPoint.lat : 18.52;
      const curLon = state.selectedPoint ? state.selectedPoint.lon : 73.85;
      if (!state.forecastData) {
        loadWeatherForecast(curLat, curLon);
      } else {
        updateForecastStep(state.forecastStepIndex || 0);
      }
      if (mapViewer && mapViewer.map) {
        setTimeout(() => mapViewer.map.invalidateSize(), 150);
      }
    } else {
      // 'imd' Mode
      if (els.windyContainer) els.windyContainer.style.display = 'none';
      if (els.mapForecastBar) els.mapForecastBar.style.display = 'none';
      if (els.btnViewImd) els.btnViewImd.classList.add('active');
      if (els.btnViewForecast) els.btnViewForecast.classList.remove('active');
      if (els.btnViewWindy) els.btnViewWindy.classList.remove('active');
      if (els.btnHeaderWindy) {
        els.btnHeaderWindy.style.background = 'linear-gradient(135deg, #0284c7, #0369a1)';
        els.btnHeaderWindy.innerHTML = '<i class="fa-solid fa-wind"></i> Windy Weather';
      }
      if (mapViewer && mapViewer.map) {
        setTimeout(() => mapViewer.map.invalidateSize(), 150);
      }
    }
  }

  function fetchLiveWeather(lat, lon) {
    fetch(`/api/weather/live?lat=${lat}&lon=${lon}`)
      .then(res => res.json())
      .then(data => {
        if (data.success && data.current) {
          const w = data.current;
          state.liveWeather = w;
          if (els.liveWeatherCondition) els.liveWeatherCondition.textContent = w.condition || 'Clear';
          if (els.liveWeatherIcon) {
            els.liveWeatherIcon.className = `fa-solid ${w.icon || 'fa-sun'}`;
            els.liveWeatherIcon.style.color = w.color || '#facc15';
          }
          if (els.liveWeatherTemp) els.liveWeatherTemp.textContent = w.temperature !== undefined ? w.temperature : '--';
          if (els.liveWeatherFeels) els.liveWeatherFeels.textContent = w.apparent_temperature !== undefined ? w.apparent_temperature : '--';
          if (els.liveWeatherWind) els.liveWeatherWind.textContent = w.wind_speed !== undefined ? w.wind_speed : '--';
          if (els.liveWeatherCompass) els.liveWeatherCompass.textContent = w.wind_compass || '--';
          if (els.liveWeatherDeg) els.liveWeatherDeg.textContent = w.wind_direction !== undefined ? w.wind_direction : '--';
          if (els.liveWeatherGusts) els.liveWeatherGusts.textContent = w.wind_gusts !== undefined ? `${w.wind_gusts} km/h` : '--';
          if (els.liveWeatherHumidity) els.liveWeatherHumidity.textContent = w.humidity !== undefined ? w.humidity : '--';
          if (els.liveWeatherPressure) els.liveWeatherPressure.textContent = w.surface_pressure !== undefined ? w.surface_pressure : '--';
          if (els.liveWeatherClouds) els.liveWeatherClouds.textContent = w.cloud_cover !== undefined ? w.cloud_cover : '--';
          if (els.liveWeatherPrecip) els.liveWeatherPrecip.textContent = w.precipitation !== undefined ? w.precipitation : '0.0';
        }
      })
      .catch(err => console.warn('Live weather fetch error:', err));
  }

  // ========================================================================
  // Weather Forecast & Interactive Timeline Slider Controller
  // ========================================================================
  function loadWeatherForecast(lat, lon) {
    fetch(`/api/weather/forecast?lat=${lat}&lon=${lon}&days=7`)
      .then(res => res.json())
      .then(data => {
        if (data.success && data.hourly) {
          state.forecastData = data;
          renderDailyForecastCards(data.daily);
          updateForecastStep(state.forecastStepIndex || 0);
          charts.renderForecastChart('forecastTimeSeriesChart', data.hourly, state.forecastStepIndex || 0);
        }
      })
      .catch(err => console.warn('Weather forecast fetch error:', err));
  }

  function renderDailyForecastCards(dailyList) {
    if (!els.pointForecastDailyRow) return;
    els.pointForecastDailyRow.innerHTML = '';
    if (!dailyList || dailyList.length === 0) return;

    dailyList.forEach((d, idx) => {
      const card = document.createElement('div');
      card.className = `forecast-day-card ${idx === 0 ? 'active' : ''}`;
      card.setAttribute('data-day-idx', idx);
      card.title = `Jump to ${d.day_name} (${d.date}): ${d.condition}`;
      card.innerHTML = `
        <div class="forecast-day-name">${d.day_name}</div>
        <div class="forecast-day-date">${d.date.slice(5)}</div>
        <div class="forecast-day-icon">
          <i class="fa-solid ${d.icon || 'fa-cloud-sun'}" style="color:${d.color || '#38bdf8'}; font-size:15px;"></i>
        </div>
        <div class="forecast-day-temp">
          <span class="max">${Math.round(d.temp_max)}°</span> / <span class="min">${Math.round(d.temp_min)}°</span>
        </div>
        <div class="forecast-day-rain">
          <i class="fa-solid fa-droplet"></i> ${d.precip_sum}mm
        </div>
      `;

      card.addEventListener('click', () => {
        const hourStep = Math.min(idx * 24, (state.forecastData && state.forecastData.hourly ? state.forecastData.hourly.length - 1 : 167));
        updateForecastStep(hourStep);
      });

      els.pointForecastDailyRow.appendChild(card);
    });
  }

  function updateForecastStep(stepIdx) {
    if (!state.forecastData || !state.forecastData.hourly || state.forecastData.hourly.length === 0) {
      return;
    }

    const totalHours = state.forecastData.hourly.length;
    if (stepIdx < 0) stepIdx = 0;
    if (stepIdx >= totalHours) stepIdx = totalHours - 1;

    state.forecastStepIndex = stepIdx;
    if (els.forecastSlider) {
      els.forecastSlider.value = stepIdx;
    }

    const h = state.forecastData.hourly[stepIdx];
    if (!h) return;

    const relLabel = h.hours_ahead === 0 ? 'Hour 0: Now' : `Hour +${h.hours_ahead}h`;
    if (els.forecastStepBadge) {
      els.forecastStepBadge.textContent = relLabel;
    }

    if (els.forecastStepLabel) {
      els.forecastStepLabel.innerHTML = `
        <i class="fa-solid ${h.icon || 'fa-cloud-sun'}" style="color:${h.color || '#38bdf8'}; margin-right:4px;"></i>
        <strong>${h.full_label || (h.date_label + ' ' + h.hour_label)}</strong> &bull;
        <span>${h.condition}</span> &bull;
        <span style="color:#f97316; font-weight:700;">${h.temperature}°C</span> &bull;
        <span style="color:#38bdf8;">Precip: ${h.precipitation} mm (${h.precipitation_probability}%)</span> &bull;
        <span>Wind: ${h.wind_speed} km/h ${h.wind_compass}</span>
      `;
    }

    // Update Quick Chips
    if (els.forecastQuickChips) {
      els.forecastQuickChips.forEach(chip => {
        const hourVal = parseInt(chip.getAttribute('data-fhour'), 10);
        if (Math.abs(hourVal - stepIdx) < 2) {
          chip.classList.add('active');
        } else {
          chip.classList.remove('active');
        }
      });
    }

    // Update Daily Cards Highlight
    const activeDayIdx = Math.floor(stepIdx / 24);
    const dayCards = document.querySelectorAll('.forecast-day-card');
    dayCards.forEach((card, idx) => {
      if (idx === activeDayIdx) {
        card.classList.add('active');
      } else {
        card.classList.remove('active');
      }
    });

    // Update Point Probe Inspector Forecast Section
    if (els.pointForecastStepBadge) {
      els.pointForecastStepBadge.textContent = relLabel;
    }
    if (els.pointForecastStepTime) {
      els.pointForecastStepTime.textContent = h.full_label || `${h.date_label} ${h.hour_label}`;
    }
    if (els.pointForecastCondition) {
      els.pointForecastCondition.innerHTML = `
        <i class="fa-solid ${h.icon || 'fa-cloud-sun'}" style="color:${h.color || '#facc15'};"></i>
        <span>${h.condition}</span>
      `;
    }
    if (els.pointForecastTemp) {
      els.pointForecastTemp.textContent = `${h.temperature}°C`;
    }
    if (els.pointForecastRain) {
      els.pointForecastRain.textContent = `Rain: ${h.precipitation} mm (${h.precipitation_probability}%)`;
    }

    // Update Live Weather Card fields during forecast scrubbing
    if (els.liveWeatherTemp) els.liveWeatherTemp.textContent = h.temperature !== undefined ? h.temperature : '--';
    if (els.liveWeatherFeels) els.liveWeatherFeels.textContent = h.apparent_temperature !== undefined ? h.apparent_temperature : '--';
    if (els.liveWeatherWind) els.liveWeatherWind.textContent = h.wind_speed !== undefined ? h.wind_speed : '--';
    if (els.liveWeatherCompass) els.liveWeatherCompass.textContent = h.wind_compass || '--';
    if (els.liveWeatherDeg) els.liveWeatherDeg.textContent = h.wind_direction !== undefined ? h.wind_direction : '--';
    if (els.liveWeatherGusts) els.liveWeatherGusts.textContent = h.wind_gusts !== undefined ? `${h.wind_gusts} km/h` : '--';
    if (els.liveWeatherHumidity) els.liveWeatherHumidity.textContent = h.humidity !== undefined ? h.humidity : '--';
    if (els.liveWeatherPressure) els.liveWeatherPressure.textContent = h.pressure !== undefined ? h.pressure : '--';
    if (els.liveWeatherClouds) els.liveWeatherClouds.textContent = h.cloud_cover !== undefined ? h.cloud_cover : '--';
    if (els.liveWeatherPrecip) els.liveWeatherPrecip.textContent = h.precipitation !== undefined ? h.precipitation : '0.0';
    if (els.liveWeatherCondition) els.liveWeatherCondition.textContent = h.condition || '--';
    if (els.liveWeatherIcon) {
      els.liveWeatherIcon.className = `fa-solid ${h.icon || 'fa-cloud-sun'}`;
      els.liveWeatherIcon.style.color = h.color || '#38bdf8';
    }

    // Update chart marker
    charts.renderForecastChart('forecastTimeSeriesChart', state.forecastData.hourly, stepIdx);
  }

  function toggleForecastPlay() {
    if (state.isForecastPlaying) {
      clearInterval(state.forecastPlayInterval);
      state.isForecastPlaying = false;
      if (els.forecastPlayIcon) {
        els.forecastPlayIcon.className = 'fa-solid fa-play';
      }
    } else {
      state.isForecastPlaying = true;
      if (els.forecastPlayIcon) {
        els.forecastPlayIcon.className = 'fa-solid fa-pause';
      }
      state.forecastPlayInterval = setInterval(() => {
        let next = state.forecastStepIndex + 3; // jump 3 hours per frame for smooth 168h projection
        if (state.forecastData && state.forecastData.hourly && next >= state.forecastData.hourly.length) {
          next = 0;
        } else if (next > 167) {
          next = 0;
        }
        updateForecastStep(next);
      }, state.forecastSpeed || 900);
    }
  }

  window.onForecastHourSelected = (hourIdx) => {
    updateForecastStep(hourIdx);
  };

  // Wire View Toggles (IMD vs Forecast vs Windy)
  if (els.btnViewImd) {
    els.btnViewImd.addEventListener('click', () => setViewMode('imd'));
  }
  if (els.btnViewForecast) {
    els.btnViewForecast.addEventListener('click', () => setViewMode('forecast'));
  }
  if (els.btnViewWindy) {
    els.btnViewWindy.addEventListener('click', () => setViewMode('windy'));
  }
  if (els.btnHeaderWindy) {
    els.btnHeaderWindy.addEventListener('click', () => {
      setViewMode(state.viewMode === 'windy' ? 'imd' : 'windy');
    });
  }
  if (els.btnSidebarLaunchWindy) {
    els.btnSidebarLaunchWindy.addEventListener('click', () => setViewMode('windy'));
  }
  if (els.btnWindyClose) {
    els.btnWindyClose.addEventListener('click', () => setViewMode('imd'));
  }

  // Wire Forecast Slider and Playback Controls
  if (els.forecastSlider) {
    els.forecastSlider.addEventListener('input', (e) => {
      updateForecastStep(parseInt(e.target.value, 10));
    });
  }
  if (els.forecastStepPrevBtn) {
    els.forecastStepPrevBtn.addEventListener('click', () => {
      updateForecastStep(state.forecastStepIndex - 3);
    });
  }
  if (els.forecastStepNextBtn) {
    els.forecastStepNextBtn.addEventListener('click', () => {
      updateForecastStep(state.forecastStepIndex + 3);
    });
  }
  if (els.forecastPlayBtn) {
    els.forecastPlayBtn.addEventListener('click', toggleForecastPlay);
  }
  if (els.forecastQuickChips) {
    els.forecastQuickChips.forEach(chip => {
      chip.addEventListener('click', (e) => {
        const hour = parseInt(e.currentTarget.getAttribute('data-fhour'), 10);
        updateForecastStep(hour);
      });
    });
  }

  // Wire Windy Layer Overlay Switchers
  if (els.windyChipBtns) {
    els.windyChipBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const target = e.currentTarget;
        els.windyChipBtns.forEach(b => b.classList.remove('active'));
        target.classList.add('active');
        const overlay = target.getAttribute('data-overlay');
        state.windyOverlay = overlay;
        updateWindyIframe(state.windyCenter.lat, state.windyCenter.lon, state.windyZoom, overlay);
      });
    });
  }

  // Wire Windy Recenter Actions
  if (els.btnWindySyncPoint) {
    els.btnWindySyncPoint.addEventListener('click', () => {
      const lat = state.selectedPoint ? state.selectedPoint.lat : 20.5937;
      const lon = state.selectedPoint ? state.selectedPoint.lon : 78.9629;
      updateWindyIframe(lat, lon, 8, state.windyOverlay);
    });
  }
  if (els.btnWindyAllIndia) {
    els.btnWindyAllIndia.addEventListener('click', () => {
      updateWindyIframe(20.5937, 78.9629, 5, state.windyOverlay);
    });
  }
  if (els.btnInspectPointInWindy) {
    els.btnInspectPointInWindy.addEventListener('click', () => {
      const lat = state.selectedPoint ? state.selectedPoint.lat : 20.5937;
      const lon = state.selectedPoint ? state.selectedPoint.lon : 78.9629;
      setViewMode('windy');
      updateWindyIframe(lat, lon, 8, state.windyOverlay);
    });
  }

  // Kickoff App Initialization
  initApp();
});
