/**
 * PMFBY Crop Insurance Analytics Dashboard Controller
 * Manages official government statistics, interactive Chart.js charts,
 * Year-wise District Filters, and Insurance Company mapping from Premium Calculator.
 */

document.addEventListener('DOMContentLoaded', () => {
  const state = {
    allData: [],
    filteredData: [],
    stateData: [],
    districtData: [],
    filteredDistricts: [],
    districtYear: '2024',
    activeView: 'national', // 'national', 'state', or 'district'
    rankingView: 'states',  // 'states', 'districts', or 'ics'
    charts: {}
  };

  // UI References
  const els = {
    filterYear: document.getElementById('filterYear'),
    filterSeason: document.getElementById('filterSeason'),
    recordCountLabel: document.getElementById('recordCountLabel'),
    
    // KPI Values
    kpiTotalApps: document.getElementById('kpiTotalApps'),
    kpiFarmerSub: document.getElementById('kpiFarmerSub'),
    kpiAreaInsured: document.getElementById('kpiAreaInsured'),
    kpiSumInsured: document.getElementById('kpiSumInsured'),
    kpiGrossPremium: document.getElementById('kpiGrossPremium'),
    kpiSubsidySub: document.getElementById('kpiSubsidySub'),
    kpiClaimsPaid: document.getElementById('kpiClaimsPaid'),
    kpiBenefitedSub: document.getElementById('kpiBenefitedSub'),
    kpiLossRatio: document.getElementById('kpiLossRatio'),

    // Table View Toggles
    btnViewNational: document.getElementById('btnViewNational'),
    btnViewStateWise: document.getElementById('btnViewStateWise'),
    btnViewDistrictWise: document.getElementById('btnViewDistrictWise'),
    districtFilterControls: document.getElementById('districtFilterControls'),
    
    // District Specific Filters
    selectDistrictYear: document.getElementById('selectDistrictYear'),
    selectDistrictState: document.getElementById('selectDistrictState'),
    selectDistrictIC: document.getElementById('selectDistrictIC'),
    searchDistrictInput: document.getElementById('searchDistrictInput'),
    btnExportDistrictCsv: document.getElementById('btnExportDistrictCsv'),

    pmfbyTableHead: document.getElementById('pmfbyTableHead'),
    pmfbyTableBody: document.getElementById('pmfbyTableBody'),

    // Ranking Chart Toggles
    chart6Title: document.getElementById('chart6Title'),
    btnRankStates: document.getElementById('btnRankStates'),
    btnRankDistricts: document.getElementById('btnRankDistricts'),
    btnRankICs: document.getElementById('btnRankICs'),

    // Daily Sync Status & Actions
    syncStatusBadge: document.getElementById('syncStatusBadge'),
    syncStatusText: document.getElementById('syncStatusText'),
    btnRefreshSync: document.getElementById('btnRefreshSync'),
    refreshSyncIcon: document.getElementById('refreshSyncIcon'),
    lblLastChecked: document.getElementById('lblLastChecked'),
    toastBox: document.getElementById('toastBox'),
    toastMsg: document.getElementById('toastMsg'),

    // Theme
    themeToggleBtn: document.getElementById('themeToggleBtn')
  };

  // Toast notification helper
  function showToast(msg, isSuccess = true) {
    if (!els.toastBox) return;
    els.toastMsg.textContent = msg;
    const icon = els.toastBox.querySelector('i');
    if (icon) {
      icon.className = isSuccess ? 'fa-solid fa-circle-check' : 'fa-solid fa-triangle-exclamation';
      icon.style.color = isSuccess ? '#22c55e' : '#ef4444';
    }
    els.toastBox.classList.add('show');
    setTimeout(() => {
      els.toastBox.classList.remove('show');
    }, 4000);
  }

  // Fetch PMFBY portal sync status
  function fetchSyncStatus() {
    fetch('/api/pmfby/sync_status')
      .then(res => res.json())
      .then(res => {
        if (res.success && res.sync_status) {
          const s = res.sync_status;
          if (els.lblLastChecked) {
            els.lblLastChecked.textContent = `Last Synced: ${s.last_checked}`;
          }
          if (els.syncStatusText) {
            els.syncStatusText.textContent = s.status === 'synced' ? 'Daily Sync Active' : 'Checking Portal...';
          }
        }
      })
      .catch(err => console.error('PMFBY sync status error:', err));
  }

  // Trigger manual sync check against PMFBY national portal
  function triggerManualSync() {
    if (els.refreshSyncIcon) els.refreshSyncIcon.classList.add('fa-spin');
    if (els.syncStatusText) els.syncStatusText.textContent = 'Checking PMFBY Portal...';
    
    showToast('Checking PMFBY national portal for updates in the background...');

    fetch('/api/pmfby/sync_refresh', { method: 'POST' })
      .then(res => res.json())
      .then(res => {
        if (els.refreshSyncIcon) els.refreshSyncIcon.classList.remove('fa-spin');
        if (res.success && res.sync_status) {
          const s = res.sync_status;
          if (els.lblLastChecked) els.lblLastChecked.textContent = `Last Synced: ${s.last_checked}`;
          if (els.syncStatusText) els.syncStatusText.textContent = 'Daily Sync Active';
          showToast(s.message || 'PMFBY national datasets verified and up to date!');
          // Reload dashboard with fresh data
          loadData(true);
        }
      })
      .catch(err => {
        if (els.refreshSyncIcon) els.refreshSyncIcon.classList.remove('fa-spin');
        showToast('Sync check finished (offline cache verified)', false);
        console.error(err);
      });
  }

  // Fetch National Summary Data & State/District Data
  function loadData(forceRefresh = false) {
    const summaryUrl = forceRefresh ? '/api/pmfby/summary?refresh=true' : '/api/pmfby/summary';
    fetch(summaryUrl)
      .then(res => res.json())
      .then(resData => {
        if (!resData.success || !resData.data) return;
        state.allData = resData.data;
        applyFilters();
      })
      .catch(err => console.error('Error fetching PMFBY summary:', err));

    // Fetch State Data for default year 2024
    fetch('/api/pmfby/state_report?year=2024&season=01')
      .then(res => res.json())
      .then(resData => {
        if (resData.success) {
          state.stateData = resData.data;
          populateStateSelect();
          renderRankingChart();
        }
      })
      .catch(err => console.error('Error fetching PMFBY state data:', err));

    // Fetch District Data with Insurance Companies for year 2024
    fetchDistrictData(state.districtYear || '2024');
  }

  function fetchDistrictData(year) {
    state.districtYear = year;
    const url = `/api/pmfby/district_report?year=${year}&season=01`;
    fetch(url)
      .then(res => res.json())
      .then(resData => {
        if (resData.success) {
          state.districtData = resData.data;
          state.filteredDistricts = resData.data;
          
          // Populate Insurance Company select dropdown dynamically
          populateCompanySelect(resData.available_companies || []);
          
          if (state.activeView === 'district') {
            filterDistrictView();
          }
          if (state.rankingView === 'districts' || state.rankingView === 'ics') {
            renderRankingChart();
          }
        }
      })
      .catch(err => console.error('Error fetching district data:', err));
  }

  function populateCompanySelect(companies) {
    if (!els.selectDistrictIC) return;
    const curVal = els.selectDistrictIC.value;
    els.selectDistrictIC.innerHTML = '<option value="all">All Insurance Companies</option>';
    
    // Sort clean names
    companies.sort().forEach(c => {
      const opt = document.createElement('option');
      opt.value = c;
      opt.textContent = formatCompanyShort(c);
      opt.title = c;
      els.selectDistrictIC.appendChild(opt);
    });

    if (curVal && Array.from(els.selectDistrictIC.options).some(o => o.value === curVal)) {
      els.selectDistrictIC.value = curVal;
    }
  }

  function populateStateSelect() {
    if (!els.selectDistrictState || !state.stateData) return;
    els.selectDistrictState.innerHTML = '<option value="all">All States</option>';
    state.stateData.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.state_code;
      opt.textContent = `${s.state_name} (${s.districts} Dist)`;
      els.selectDistrictState.appendChild(opt);
    });
  }

  function formatCompanyShort(raw) {
    if (!raw) return 'AIC of India';
    const u = raw.toUpperCase();
    if (u.includes('AGRICULTURE INSURANCE') || u.includes('AIC')) return 'AIC of India';
    if (u.includes('BAJAJ')) return 'Bajaj Allianz';
    if (u.includes('UNIVERSAL SOMPO')) return 'Universal Sompo';
    if (u.includes('FUTURE GENERALI')) return 'Future Generali';
    if (u.includes('HDFC')) return 'HDFC ERGO';
    if (u.includes('ICICI')) return 'ICICI Lombard';
    if (u.includes('IFFCO')) return 'IFFCO TOKIO';
    if (u.includes('RELIANCE')) return 'Reliance General';
    if (u.includes('SBI')) return 'SBI General';
    if (u.includes('TATA')) return 'Tata AIG';
    if (u.includes('CHOLA')) return 'Cholamandalam MS';
    if (u.includes('NATIONAL INSURANCE')) return 'National Insurance';
    if (u.includes('NEW INDIA')) return 'New India Assurance';
    if (u.includes('ORIENTAL')) return 'Oriental Insurance';
    if (u.includes('UNITED INDIA')) return 'United India';
    if (u.includes('KSHEMA')) return 'Kshema General';
    return raw.length > 20 ? raw.substring(0, 18) + '...' : raw;
  }

  // Filter Data based on UI Controls
  function applyFilters() {
    const yearVal = els.filterYear.value;
    const seasonVal = els.filterSeason.value;

    state.filteredData = state.allData.filter(d => {
      const matchYear = (yearVal === 'all') || (d.year.toString() === yearVal);
      const matchSeason = (seasonVal === 'all') || (d.season_code === seasonVal);
      return matchYear && matchSeason;
    });

    if (state.activeView === 'district') {
      els.recordCountLabel.textContent = `${state.filteredDistricts.length} Districts Displayed (${state.districtYear})`;
    } else if (state.activeView === 'state') {
      els.recordCountLabel.textContent = `${state.stateData.length} States Displayed`;
    } else {
      els.recordCountLabel.textContent = `${state.filteredData.length} Season Records Loaded`;
    }

    updateKPIs();
    renderCharts();
    renderTable();
  }

  // Calculate & Update Executive KPIs
  function updateKPIs() {
    const data = state.filteredData;
    if (data.length === 0) return;

    let totalApps = 0;
    let totalFarmers = 0;
    let totalArea = 0;
    let totalSumInsured = 0;
    let totalPremium = 0;
    let totalFarmerPrem = 0;
    let totalGoi = 0;
    let totalState = 0;
    let totalClaims = 0;
    let totalBenefited = 0;

    data.forEach(d => {
      totalApps += d.total_applications || 0;
      totalFarmers += d.farmer_count || 0;
      totalArea += d.area_insured_lakh_ha || 0;
      totalSumInsured += d.sum_insured_crore || 0;
      totalPremium += d.gross_premium_crore || 0;
      totalFarmerPrem += d.farmer_premium_crore || 0;
      totalGoi += d.goi_subsidy_crore || 0;
      totalState += d.state_subsidy_crore || 0;
      totalClaims += d.claims_paid_crore || 0;
      totalBenefited += d.benefited_farmers || 0;
    });

    const overallLossRatio = totalPremium > 0 ? (totalClaims / totalPremium * 100).toFixed(1) : '0.0';

    els.kpiTotalApps.textContent = formatToCrores(totalApps);
    els.kpiFarmerSub.textContent = `${formatToCrores(totalFarmers)} unique farmers`;

    els.kpiAreaInsured.textContent = `${(totalArea).toLocaleString('en-IN', { maximumFractionDigits: 1 })}`;
    els.kpiSumInsured.textContent = `₹${(totalSumInsured / 100000).toFixed(2)} L. Cr`;
    els.kpiGrossPremium.textContent = `₹${formatToCrores(totalPremium)}`;
    els.kpiSubsidySub.textContent = `₹${formatToCrores(totalGoi + totalState)} Govt Subsidy`;

    els.kpiClaimsPaid.textContent = `₹${formatToCrores(totalClaims)}`;
    els.kpiBenefitedSub.textContent = `${formatToCrores(totalBenefited)} benefited farmers`;

    els.kpiLossRatio.textContent = `${overallLossRatio}%`;
  }

  function formatToCrores(val) {
    if (val >= 10000000) {
      return `${(val / 10000000).toFixed(2)} Cr`;
    } else if (val >= 100000) {
      return `${(val / 100000).toFixed(2)} Lakh`;
    }
    return val.toLocaleString('en-IN');
  }

  // =========================================================================
  // Render Chart.js Visualizations
  // =========================================================================
  function renderCharts() {
    renderEnrollmentGrowthChart();
    renderPremiumBreakdownChart();
    renderClaimsVsPremiumChart();
    renderClaimStagesChart();
    renderDemographicsChart();
    renderRankingChart();
  }

  // Chart 1: Enrollment Growth & Area Insured
  function renderEnrollmentGrowthChart() {
    const ctx = document.getElementById('chartEnrollmentGrowth');
    if (!ctx) return;
    if (state.charts.enrollment) state.charts.enrollment.destroy();

    const labels = state.filteredData.map(d => d.display_name);
    const appsInLakhs = state.filteredData.map(d => (d.total_applications / 100000).toFixed(1));
    const areaInLakhHa = state.filteredData.map(d => d.area_insured_lakh_ha);

    state.charts.enrollment = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            type: 'bar',
            label: 'Farmer Applications (Lakh)',
            data: appsInLakhs,
            backgroundColor: 'rgba(56, 189, 248, 0.75)',
            borderColor: '#38bdf8',
            borderWidth: 1,
            borderRadius: 4,
            yAxisID: 'y'
          },
          {
            type: 'line',
            label: 'Area Insured (Lakh Hectares)',
            data: areaInLakhHa,
            borderColor: '#22c55e',
            backgroundColor: '#22c55e',
            borderWidth: 2.5,
            pointRadius: 3,
            tension: 0.3,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top', labels: { boxWidth: 12, color: '#94a3b8', font: { size: 10 } } }
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 9 }, maxRotation: 45 } },
          y: {
            title: { display: true, text: 'Applications (Lakh)', color: '#94a3b8', font: { size: 10 } },
            ticks: { color: '#64748b', font: { size: 9 } },
            grid: { color: 'rgba(51, 65, 85, 0.3)' }
          },
          y1: {
            position: 'right',
            title: { display: true, text: 'Area (Lakh Ha)', color: '#22c55e', font: { size: 10 } },
            ticks: { color: '#22c55e', font: { size: 9 } },
            grid: { display: false }
          }
        }
      }
    });
  }

  // Chart 2: Premium Burden Sharing (Subsidies)
  function renderPremiumBreakdownChart() {
    const ctx = document.getElementById('chartPremiumBreakdown');
    if (!ctx) return;
    if (state.charts.premium) state.charts.premium.destroy();

    const labels = state.filteredData.map(d => d.display_name);
    const farmerShare = state.filteredData.map(d => d.farmer_premium_crore);
    const goiShare = state.filteredData.map(d => d.goi_subsidy_crore);
    const stateShare = state.filteredData.map(d => d.state_subsidy_crore);

    state.charts.premium = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Farmer Premium Paid (₹ Cr)',
            data: farmerShare,
            backgroundColor: '#38bdf8',
            stack: 'combined'
          },
          {
            label: 'Central Govt Subsidy (₹ Cr)',
            data: goiShare,
            backgroundColor: '#f59e0b',
            stack: 'combined'
          },
          {
            label: 'State Govt Subsidy (₹ Cr)',
            data: stateShare,
            backgroundColor: '#10b981',
            stack: 'combined'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top', labels: { boxWidth: 12, color: '#94a3b8', font: { size: 10 } } }
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 9 }, maxRotation: 45 } },
          y: {
            stacked: true,
            title: { display: true, text: 'Premium Amount (₹ Crore)', color: '#94a3b8', font: { size: 10 } },
            ticks: { color: '#64748b', font: { size: 9 } },
            grid: { color: 'rgba(51, 65, 85, 0.3)' }
          }
        }
      }
    });
  }

  // Chart 3: Claims Paid vs. Gross Premium Comparison
  function renderClaimsVsPremiumChart() {
    const ctx = document.getElementById('chartClaimsVsPremium');
    if (!ctx) return;
    if (state.charts.claimsVsPremium) state.charts.claimsVsPremium.destroy();

    const labels = state.filteredData.map(d => d.display_name);
    const premium = state.filteredData.map(d => d.gross_premium_crore);
    const claims = state.filteredData.map(d => d.claims_paid_crore);
    const lossRatios = state.filteredData.map(d => d.loss_ratio_pct);

    state.charts.claimsVsPremium = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            type: 'bar',
            label: 'Gross Premium (₹ Cr)',
            data: premium,
            backgroundColor: 'rgba(2, 132, 199, 0.6)',
            borderColor: '#0284c7',
            borderWidth: 1,
            borderRadius: 4,
            yAxisID: 'y'
          },
          {
            type: 'bar',
            label: 'Claims Settled (₹ Cr)',
            data: claims,
            backgroundColor: 'rgba(239, 68, 68, 0.7)',
            borderColor: '#ef4444',
            borderWidth: 1,
            borderRadius: 4,
            yAxisID: 'y'
          },
          {
            type: 'line',
            label: 'Claim Ratio (%)',
            data: lossRatios,
            borderColor: '#f59e0b',
            borderWidth: 2,
            pointRadius: 3,
            tension: 0.2,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top', labels: { boxWidth: 12, color: '#94a3b8', font: { size: 10 } } }
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 9 }, maxRotation: 45 } },
          y: {
            title: { display: true, text: 'Amount (₹ Crore)', color: '#94a3b8', font: { size: 10 } },
            ticks: { color: '#64748b', font: { size: 9 } },
            grid: { color: 'rgba(51, 65, 85, 0.3)' }
          },
          y1: {
            position: 'right',
            title: { display: true, text: 'Loss Ratio (%)', color: '#f59e0b', font: { size: 10 } },
            ticks: { color: '#f59e0b', font: { size: 9 } },
            grid: { display: false }
          }
        }
      }
    });
  }

  // Chart 4: 5-Stage Claim Type Breakdown
  function renderClaimStagesChart() {
    const ctx = document.getElementById('chartClaimStages');
    if (!ctx) return;
    if (state.charts.claimStages) state.charts.claimStages.destroy();

    let pSowing = 0, midTerm = 0, localised = 0, postHarvest = 0, yieldLoss = 0, rwbcis = 0;
    state.filteredData.forEach(d => {
      pSowing += d.claim_prevented_sowing_lakh || 0;
      midTerm += d.claim_mid_term_lakh || 0;
      localised += d.claim_localised_lakh || 0;
      postHarvest += d.claim_post_harvest_lakh || 0;
      yieldLoss += d.claim_yield_lakh || 0;
      rwbcis += d.claim_rwbcis_lakh || 0;
    });

    state.charts.claimStages = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: [
          'End-of-Season Yield Loss (CCE)',
          'Mid-Season Adversity',
          'Localised Calamities (Hailstorm/Floods)',
          'Post-Harvest Losses',
          'Prevented Sowing',
          'Weather Index (RWBCIS)'
        ],
        datasets: [{
          data: [
            Math.round(yieldLoss / 100),
            Math.round(midTerm / 100),
            Math.round(localised / 100),
            Math.round(postHarvest / 100),
            Math.round(pSowing / 100),
            Math.round(rwbcis / 100)
          ],
          backgroundColor: [
            '#dc2626',
            '#f59e0b',
            '#38bdf8',
            '#10b981',
            '#a855f7',
            '#64748b'
          ],
          borderColor: 'rgba(15, 23, 42, 0.8)',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'right', labels: { boxWidth: 12, color: '#94a3b8', font: { size: 10 } } },
          tooltip: {
            callbacks: {
              label: (ctx) => ` ₹${ctx.parsed.toLocaleString('en-IN')} Crore (${ctx.label})`
            }
          }
        }
      }
    });
  }

  // Chart 5: Inclusivity & Farmer Demographics
  function renderDemographicsChart() {
    const ctx = document.getElementById('chartDemographics');
    if (!ctx) return;
    if (state.charts.demographics) state.charts.demographics.destroy();

    const latest = state.filteredData[state.filteredData.length - 1] || {};
    const smPct = ((latest.small_pct || 68.4) + (latest.marginal_pct || 15.2)).toFixed(1);
    const otherPct = (latest.other_farm_pct || 16.4).toFixed(1);

    state.charts.demographics = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Small & Marginal (<2 Ha)', 'Other Farmers (>2 Ha)', 'OBC Category', 'General Category', 'SC / ST Category', 'Female Farmers'],
        datasets: [{
          label: 'Coverage Percentage (%)',
          data: [smPct, otherPct, latest.obc_pct || 48.2, latest.gen_pct || 36.5, (latest.sc_pct || 6.5) + (latest.st_pct || 8.8), latest.female_pct || 18.5],
          backgroundColor: [
            '#10b981',
            '#3b82f6',
            '#f59e0b',
            '#8b5cf6',
            '#ec4899',
            '#06b6d4'
          ],
          borderRadius: 4
        }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => ` ${ctx.parsed.x}% of Enrolled Farmers`
            }
          }
        },
        scales: {
          x: { max: 100, ticks: { callback: v => `${v}%`, color: '#64748b', font: { size: 9 } }, grid: { color: 'rgba(51, 65, 85, 0.3)' } },
          y: { ticks: { color: '#94a3b8', font: { size: 10 } }, grid: { display: false } }
        }
      }
    });
  }

  // Chart 6: State, District, and Insurance Company Ranking
  function renderRankingChart() {
    const ctx = document.getElementById('chartStateRanking');
    if (!ctx) return;
    if (state.charts.ranking) state.charts.ranking.destroy();

    let labels = [];
    let primaryMetric = [];
    let secondaryMetric = [];
    let primaryLabel = 'Enrolled Farmers (Lakh)';
    let secondaryLabel = 'Claims Settled (₹ Cr)';

    if (state.rankingView === 'ics' && state.districtData && state.districtData.length > 0) {
      els.chart6Title.textContent = `Insurance Company Ranking (${state.districtYear})`;
      
      // Aggregate districts by Insurance Company
      const icMap = {};
      state.districtData.forEach(d => {
        const cShort = d.insurance_company_short || 'AIC of India';
        if (!icMap[cShort]) {
          icMap[cShort] = { name: cShort, farmers: 0, claims: 0, districts: 0 };
        }
        icMap[cShort].farmers += d.farmer_count;
        icMap[cShort].claims += d.claims_paid_crore;
        icMap[cShort].districts += 1;
      });

      const sortedICs = Object.values(icMap).sort((a, b) => b.farmers - a.farmers).slice(0, 8);
      labels = sortedICs.map(ic => `${ic.name} (${ic.districts} Dist)`);
      primaryMetric = sortedICs.map(ic => (ic.farmers / 100000).toFixed(1));
      secondaryMetric = sortedICs.map(ic => ic.claims.toFixed(1));

    } else if (state.rankingView === 'districts' && state.districtData && state.districtData.length > 0) {
      els.chart6Title.textContent = `Top Districts by Farmer Enrollment & Claims (${state.districtYear})`;
      const topDists = state.districtData.slice(0, 8);
      labels = topDists.map(d => `${d.district_name} (${d.state_name.substring(0, 4)})`);
      primaryMetric = topDists.map(d => (d.farmer_count / 1000).toFixed(1)); // in Thousands
      secondaryMetric = topDists.map(d => d.claims_paid_crore);
      primaryLabel = 'Enrolled Farmers (Thousand)';

    } else if (state.stateData && state.stateData.length > 0) {
      els.chart6Title.textContent = 'State Performance Ranking';
      const topStates = state.stateData.slice(0, 8);
      labels = topStates.map(s => s.state_name);
      primaryMetric = topStates.map(s => (s.farmer_count / 100000).toFixed(1)); // in Lakhs
      secondaryMetric = topStates.map(s => s.claims_paid_crore);
    }

    state.charts.ranking = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: primaryLabel,
            data: primaryMetric,
            backgroundColor: '#0284c7',
            borderRadius: 4
          },
          {
            label: secondaryLabel,
            data: secondaryMetric,
            backgroundColor: '#ef4444',
            borderRadius: 4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top', labels: { boxWidth: 12, color: '#94a3b8', font: { size: 10 } } }
        },
        scales: {
          x: { ticks: { color: '#64748b', font: { size: 9 }, maxRotation: 25 }, grid: { display: false } },
          y: { ticks: { color: '#64748b', font: { size: 9 } }, grid: { color: 'rgba(51, 65, 85, 0.3)' } }
        }
      }
    });
  }

  // =========================================================================
  // Render Interactive Data Tables
  // =========================================================================
  function renderTable() {
    if (state.activeView === 'district') {
      renderDistrictTable();
    } else if (state.activeView === 'state') {
      renderStateTable();
    } else {
      renderNationalTable();
    }
  }

  function renderNationalTable() {
    els.pmfbyTableHead.innerHTML = `
      <tr>
        <th>Season &amp; Year</th>
        <th class="num-col">States</th>
        <th class="num-col">Districts</th>
        <th class="num-col">Farmers</th>
        <th class="num-col">Applications</th>
        <th class="num-col">Area Insured (L.Ha)</th>
        <th class="num-col">Sum Insured (₹ Cr)</th>
        <th class="num-col">Gross Premium (₹ Cr)</th>
        <th class="num-col">Claims Paid (₹ Cr)</th>
        <th class="num-col">Claim Ratio</th>
      </tr>
    `;

    els.pmfbyTableBody.innerHTML = '';
    state.filteredData.forEach(d => {
      const tr = document.createElement('tr');
      const badgeClass = d.season_code === '01' ? 'badge-kharif' : 'badge-rabi';
      tr.innerHTML = `
        <td>
          <strong>${d.display_name}</strong>
          <span class="badge-season ${badgeClass}">${d.season_name}</span>
        </td>
        <td class="num-cell">${d.state_count}</td>
        <td class="num-cell">${d.district_count}</td>
        <td class="num-cell">${(d.farmer_count).toLocaleString('en-IN')}</td>
        <td class="num-cell">${(d.total_applications).toLocaleString('en-IN')}</td>
        <td class="num-cell">${d.area_insured_lakh_ha.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell">${d.sum_insured_crore.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell">${d.gross_premium_crore.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell" style="color:#ef4444;font-weight:700;">${d.claims_paid_crore.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell" style="color:${d.loss_ratio_pct > 80 ? '#ef4444' : '#22c55e'};">${d.loss_ratio_pct}%</td>
      `;
      els.pmfbyTableBody.appendChild(tr);
    });
  }

  function renderStateTable() {
    els.pmfbyTableHead.innerHTML = `
      <tr>
        <th>State Name</th>
        <th>Season</th>
        <th class="num-col">Districts</th>
        <th class="num-col">Farmers Enrolled</th>
        <th class="num-col">Non-Loanee</th>
        <th class="num-col">Area Insured (L.Ha)</th>
        <th class="num-col">Sum Insured (₹ Cr)</th>
        <th class="num-col">Gross Premium (₹ Cr)</th>
        <th class="num-col">Claims Paid (₹ Cr)</th>
        <th class="num-col">Beneficiary Farmers</th>
      </tr>
    `;

    els.pmfbyTableBody.innerHTML = '';
    if (!state.stateData || state.stateData.length === 0) {
      els.pmfbyTableBody.innerHTML = '<tr><td colspan="10" style="text-align:center;color:#64748b;">No state-level data loaded.</td></tr>';
      return;
    }

    state.stateData.forEach(s => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${s.state_name}</strong></td>
        <td><span class="badge-season badge-kharif">${s.season} ${s.year}</span></td>
        <td class="num-cell">${s.districts}</td>
        <td class="num-cell">${(s.farmer_count).toLocaleString('en-IN')}</td>
        <td class="num-cell">${(s.non_loanee).toLocaleString('en-IN')}</td>
        <td class="num-cell">${s.area_insured_lakh_ha.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell">${s.sum_insured_crore.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell">${s.gross_premium_crore.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell" style="color:#ef4444;font-weight:700;">${s.claims_paid_crore.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell">${(s.benefited_farmers).toLocaleString('en-IN')}</td>
      `;
      els.pmfbyTableBody.appendChild(tr);
    });
  }

  function renderDistrictTable() {
    els.pmfbyTableHead.innerHTML = `
      <tr>
        <th>State</th>
        <th>District Name</th>
        <th>Designated Insurance Company</th>
        <th class="num-col">Units</th>
        <th class="num-col">Farmers Enrolled</th>
        <th class="num-col">Non-Loanee</th>
        <th class="num-col">Area (L.Ha)</th>
        <th class="num-col">Sum Insured (₹ Cr)</th>
        <th class="num-col">Premium (₹ Cr)</th>
        <th class="num-col">Claims (₹ Cr)</th>
        <th class="num-col">Beneficiaries</th>
        <th class="num-col">Claim Ratio</th>
      </tr>
    `;

    els.pmfbyTableBody.innerHTML = '';
    const dists = state.filteredDistricts;

    if (!dists || dists.length === 0) {
      els.pmfbyTableBody.innerHTML = '<tr><td colspan="12" style="text-align:center;color:#64748b;padding:24px;">No matching districts found for selected Year, State, or Insurance Company filter.</td></tr>';
      return;
    }

    dists.forEach(d => {
      const tr = document.createElement('tr');
      const icShort = d.insurance_company_short || formatCompanyShort(d.insurance_company);
      
      tr.innerHTML = `
        <td><span style="font-size:11px;color:var(--text-muted);font-weight:600;">${d.state_name}</span></td>
        <td><strong>${d.district_name}</strong></td>
        <td>
          <span class="badge-season" style="background:rgba(2, 132, 199, 0.12); color:#0284c7; border:1px solid rgba(2, 132, 199, 0.25); font-weight:600; font-size:11px;" title="${d.insurance_company}">
            <i class="fa-solid fa-building-shield" style="margin-right:4px;"></i>${icShort}
          </span>
        </td>
        <td class="num-cell">${d.iu_count}</td>
        <td class="num-cell">${(d.farmer_count).toLocaleString('en-IN')}</td>
        <td class="num-cell">${(d.non_loanee).toLocaleString('en-IN')}</td>
        <td class="num-cell">${d.area_insured_lakh_ha.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
        <td class="num-cell">${d.sum_insured_crore.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell">${d.gross_premium_crore.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell" style="color:#ef4444;font-weight:700;">${d.claims_paid_crore.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
        <td class="num-cell">${(d.benefited_farmers).toLocaleString('en-IN')}</td>
        <td class="num-cell" style="color:${d.loss_ratio_pct > 80 ? '#ef4444' : '#22c55e'};">${d.loss_ratio_pct}%</td>
      `;
      els.pmfbyTableBody.appendChild(tr);
    });
  }

  // Filter districts by Year, State, Insurance Company & Search Text
  function filterDistrictView() {
    const selectedState = els.selectDistrictState.value;
    const selectedIC = els.selectDistrictIC.value;
    const searchVal = els.searchDistrictInput.value.toLowerCase().trim();

    state.filteredDistricts = state.districtData.filter(d => {
      const matchState = (selectedState === 'all') || (d.state_code === selectedState);
      const matchIC = (selectedIC === 'all') || (d.insurance_company === selectedIC) || (d.insurance_company_short === selectedIC);
      const matchSearch = (!searchVal) || 
                          (d.district_name.toLowerCase().includes(searchVal)) || 
                          (d.state_name.toLowerCase().includes(searchVal)) ||
                          ((d.insurance_company || '').toLowerCase().includes(searchVal)) ||
                          ((d.insurance_company_short || '').toLowerCase().includes(searchVal));
      return matchState && matchIC && matchSearch;
    });

    els.recordCountLabel.textContent = `${state.filteredDistricts.length} Districts Displayed (${state.districtYear})`;
    
    // Update CSV Export link
    let csvUrl = `/api/pmfby/export/districts_csv?year=${state.districtYear}&season=01`;
    if (selectedState !== 'all') csvUrl += `&state=${selectedState}`;
    if (selectedIC !== 'all') csvUrl += `&company=${encodeURIComponent(selectedIC)}`;
    els.btnExportDistrictCsv.setAttribute('href', csvUrl);

    renderDistrictTable();
  }

  // =========================================================================
  // Event Listeners
  // =========================================================================
  els.filterYear.addEventListener('change', applyFilters);
  els.filterSeason.addEventListener('change', applyFilters);

  // Table view toggles
  els.btnViewNational.addEventListener('click', () => {
    state.activeView = 'national';
    els.btnViewNational.classList.add('active');
    els.btnViewStateWise.classList.remove('active');
    els.btnViewDistrictWise.classList.remove('active');
    els.districtFilterControls.style.display = 'none';
    els.btnExportDistrictCsv.style.display = 'none';
    els.recordCountLabel.textContent = `${state.filteredData.length} Season Records Loaded`;
    renderTable();
  });

  els.btnViewStateWise.addEventListener('click', () => {
    state.activeView = 'state';
    els.btnViewStateWise.classList.add('active');
    els.btnViewNational.classList.remove('active');
    els.btnViewDistrictWise.classList.remove('active');
    els.districtFilterControls.style.display = 'none';
    els.btnExportDistrictCsv.style.display = 'none';
    els.recordCountLabel.textContent = `${state.stateData.length} States Displayed`;
    renderTable();
  });

  els.btnViewDistrictWise.addEventListener('click', () => {
    state.activeView = 'district';
    els.btnViewDistrictWise.classList.add('active');
    els.btnViewNational.classList.remove('active');
    els.btnViewStateWise.classList.remove('active');
    els.districtFilterControls.style.display = 'flex';
    els.btnExportDistrictCsv.style.display = 'inline-flex';
    filterDistrictView();
  });

  // District filter inputs: Year, State, Insurance Company, Search
  els.selectDistrictYear.addEventListener('change', (e) => {
    fetchDistrictData(e.target.value);
  });

  els.selectDistrictState.addEventListener('change', filterDistrictView);
  els.selectDistrictIC.addEventListener('change', filterDistrictView);
  els.searchDistrictInput.addEventListener('input', filterDistrictView);

  // Chart 6 Ranking view toggles (States vs Districts vs Insurance Companies)
  els.btnRankStates.addEventListener('click', () => {
    state.rankingView = 'states';
    els.btnRankStates.classList.add('active');
    els.btnRankDistricts.classList.remove('active');
    els.btnRankICs.classList.remove('active');
    renderRankingChart();
  });

  els.btnRankDistricts.addEventListener('click', () => {
    state.rankingView = 'districts';
    els.btnRankDistricts.classList.add('active');
    els.btnRankStates.classList.remove('active');
    els.btnRankICs.classList.remove('active');
    renderRankingChart();
  });

  els.btnRankICs.addEventListener('click', () => {
    state.rankingView = 'ics';
    els.btnRankICs.classList.add('active');
    els.btnRankStates.classList.remove('active');
    els.btnRankDistricts.classList.remove('active');
    renderRankingChart();
  });

  // Theme toggle
  els.themeToggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    els.themeToggleBtn.innerHTML = isLight ? '<i class="fa-solid fa-moon"></i>' : '<i class="fa-solid fa-sun"></i>';
  });

  // Daily Sync Check Button
  if (els.btnRefreshSync) {
    els.btnRefreshSync.addEventListener('click', triggerManualSync);
  }

  // Periodic polling for sync status every 10 minutes
  setInterval(fetchSyncStatus, 10 * 60 * 1000);

  // Kickoff
  fetchSyncStatus();
  loadData();
});
