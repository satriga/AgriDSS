/**
 * PMFBY Insurance Company Multi-Year Analytics & Dynamic Daily Sync
 * AgriDSS Crop Insurance Module
 */

(function () {
  'use strict';

  // Global state
  const state = {
    level: 'company', // 'company', 'state', or 'district'
    year: 'all',
    season: 'all',
    scheme: 'all',
    company: 'all',
    stateCode: 'all',
    search: '',
    data: [],
    summary: {},
    availableCompanies: [],
    availableStates: [],
    availableYears: [],
    charts: {}
  };

  // DOM Elements
  const els = {
    btnLevelCompany: document.getElementById('btnLevelCompany'),
    btnLevelState: document.getElementById('btnLevelState'),
    btnLevelDistrict: document.getElementById('btnLevelDistrict'),
    btnLevelCrop: document.getElementById('btnLevelCrop'),
    selCompany: document.getElementById('selCompany'),
    selYear: document.getElementById('selYear'),
    selSeason: document.getElementById('selSeason'),
    selScheme: document.getElementById('selScheme'),
    selState: document.getElementById('selState'),
    txtSearch: document.getElementById('txtSearch'),
    lblRecordsCount: document.getElementById('lblRecordsCount'),
    lblLastChecked: document.getElementById('lblLastChecked'),
    syncStatusBadge: document.getElementById('syncStatusBadge'),
    syncStatusText: document.getElementById('syncStatusText'),
    btnRefreshSync: document.getElementById('btnRefreshSync'),
    refreshSyncIcon: document.getElementById('refreshSyncIcon'),
    btnTopExcelDownload: document.getElementById('btnTopExcelDownload'),
    btnExportCsv: document.getElementById('btnExportCsv'),
    btnExportExcel: document.getElementById('btnExportExcel'),
    tableTitleText: document.getElementById('tableTitleText'),
    tableFilterTag: document.getElementById('tableFilterTag'),
    tblHead: document.getElementById('tblHead'),
    tblBody: document.getElementById('tblBody'),
    toastBox: document.getElementById('toastBox'),
    toastMsg: document.getElementById('toastMsg'),
    themeToggleBtn: document.getElementById('themeToggleBtn'),
    // KPI Cards
    kpiTitle1: document.getElementById('kpiTitle1'),
    kpiVal1: document.getElementById('kpiVal1'),
    kpiSub1: document.getElementById('kpiSub1'),
    kpiVal2: document.getElementById('kpiVal2'),
    kpiVal3: document.getElementById('kpiVal3'),
    kpiVal4: document.getElementById('kpiVal4'),
    kpiVal5: document.getElementById('kpiVal5'),
    kpiVal6: document.getElementById('kpiVal6'),
    // Charts
    chartCompanyShare: document.getElementById('chartCompanyShare'),
    chartPremiumClaims: document.getElementById('chartPremiumClaims'),
    chartLossRatio: document.getElementById('chartLossRatio'),
    chartSchemeSeason: document.getElementById('chartSchemeSeason')
  };

  // Formatting helpers
  function fmtNum(n) {
    if (n === null || n === undefined || isNaN(n)) return '0';
    return Number(n).toLocaleString('en-IN');
  }

  function fmtCrore(n) {
    if (n === null || n === undefined || isNaN(n)) return '₹0.00 Cr';
    return `₹${Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} Cr`;
  }

  function fmtLakh(n) {
    if (n === null || n === undefined || isNaN(n)) return '0.00 L';
    return `${Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} L`;
  }

  function getRateBadge(rate) {
    const v = Number(rate || 0);
    return `<span class="badge-rate-pill">${v.toFixed(2)}%</span>`;
  }

  function getLrBadge(lr, titleText = '') {
    const v = Number(lr || 0);
    let bg = 'rgba(16, 185, 129, 0.15)';
    let color = '#10b981';
    if (v > 100) {
      bg = 'rgba(239, 68, 68, 0.15)';
      color = '#ef4444';
    } else if (v > 75) {
      bg = 'rgba(245, 158, 11, 0.15)';
      color = '#f59e0b';
    }
    const tip = titleText ? `title="${titleText}"` : '';
    return `<span class="badge-hist-lr" style="background:${bg}; color:${color};" ${tip}>${v.toFixed(1)}%</span>`;
  }

  function showToast(msg, isSuccess = true) {
    if (!els.toastBox) return;
    els.toastMsg.textContent = msg;
    const icon = els.toastBox.querySelector('i');
    if (icon) {
      icon.className = isSuccess ? 'fa-solid fa-circle-check' : 'fa-solid fa-triangle-exclamation';
      icon.style.color = isSuccess ? '#22c55e' : '#ef4444';
    }
    els.toastBox.classList.add('show');
    setTimeout(() => {
      els.toastBox.classList.remove('show');
    }, 4000);
  }

  // Fetch sync status
  function fetchSyncStatus() {
    fetch('/api/pmfby/sync_status')
      .then(res => res.json())
      .then(res => {
        if (res.success && res.sync_status) {
          const s = res.sync_status;
          if (els.lblLastChecked) {
            els.lblLastChecked.textContent = `Last Synced: ${s.last_checked}`;
          }
          if (els.syncStatusText) {
            els.syncStatusText.textContent = s.status === 'synced' ? 'Daily Sync Active' : 'Checking Portal...';
          }
        }
      })
      .catch(err => console.error('Sync status error:', err));
  }

  // Trigger manual sync check
  function triggerManualSync() {
    if (els.refreshSyncIcon) els.refreshSyncIcon.classList.add('fa-spin');
    if (els.syncStatusText) els.syncStatusText.textContent = 'Checking PMFBY Portal...';
    
    showToast('Checking PMFBY government portal for updates in the background...');

    fetch('/api/pmfby/sync_refresh', { method: 'POST' })
      .then(res => res.json())
      .then(res => {
        if (els.refreshSyncIcon) els.refreshSyncIcon.classList.remove('fa-spin');
        if (res.success && res.sync_status) {
          const s = res.sync_status;
          if (els.lblLastChecked) els.lblLastChecked.textContent = `Last Synced: ${s.last_checked}`;
          if (els.syncStatusText) els.syncStatusText.textContent = 'Daily Sync Active';
          showToast(s.message || 'PMFBY datasets verified and up to date!');
          fetchData(); // Reload view with fresh data
        }
      })
      .catch(err => {
        if (els.refreshSyncIcon) els.refreshSyncIcon.classList.remove('fa-spin');
        showToast('Sync check finished (offline cache verified)', false);
        console.error(err);
      });
  }

  // Update export links
  function updateExportLinks() {
    const params = new URLSearchParams({
      level: state.level,
      year: state.year,
      season: state.season,
      scheme: state.scheme,
      company: state.company,
      state: state.stateCode
    });
    if (state.search) params.set('search', state.search);

    const qs = params.toString();
    const excelUrl = `/api/pmfby/export/company_excel?${qs}`;
    const csvUrl = `/api/pmfby/export/company_csv?${qs}`;

    if (els.btnTopExcelDownload) els.btnTopExcelDownload.href = excelUrl;
    if (els.btnExportExcel) els.btnExportExcel.href = excelUrl;
    if (els.btnExportCsv) els.btnExportCsv.href = csvUrl;
  }

  // Fetch company analytics data
  function fetchData() {
    updateExportLinks();

    const params = new URLSearchParams({
      level: state.level,
      year: state.year,
      season: state.season,
      scheme: state.scheme,
      company: state.company,
      state: state.stateCode
    });
    if (state.search) params.set('search', state.search);

    if (els.tblBody) {
      els.tblBody.innerHTML = `
        <tr>
          <td colspan="12" style="text-align:center; padding:32px; color:var(--text-secondary);">
            <i class="fa-solid fa-spinner fa-spin"></i> Loading ${state.level.toUpperCase()} records...
          </td>
        </tr>`;
    }

    fetch(`/api/pmfby/company_analytics?${params.toString()}`)
      .then(res => res.json())
      .then(res => {
        if (!res.success) throw new Error(res.error || 'Failed to load analytics');

        state.data = res.data || [];
        state.summary = res.summary || {};
        state.availableCompanies = res.available_companies || [];
        state.availableStates = res.available_states || [];
        state.availableYears = res.available_years || [];

        populateFilterDropdowns();
        renderKPIs();
        renderTable();
        renderCharts();

        if (els.lblRecordsCount) {
          const typeName = state.level === 'company' ? 'Companies' : (state.level === 'state' ? 'State Reports' : (state.level === 'district' ? 'Districts' : 'District Crop Rates'));
          els.lblRecordsCount.textContent = `${state.data.length} ${typeName} Loaded`;
        }
      })
      .catch(err => {
        console.error('Error fetching analytics:', err);
        if (els.tblBody) {
          els.tblBody.innerHTML = `
            <tr>
              <td colspan="12" style="text-align:center; padding:32px; color:#ef4444;">
                <i class="fa-solid fa-circle-exclamation"></i> Error loading data: ${err.message}
              </td>
            </tr>`;
        }
      });
  }

  // Populate dynamic dropdowns
  function populateFilterDropdowns() {
    // Populate Companies if needed
    if (els.selCompany && els.selCompany.options.length <= 1) {
      const cur = els.selCompany.value;
      els.selCompany.innerHTML = '<option value="all">All Insurance Companies</option>';
      state.availableCompanies.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c;
        opt.textContent = c;
        els.selCompany.appendChild(opt);
      });
      if (cur) els.selCompany.value = cur;
    }

    // Populate Years if needed (all years from PMFBY premium calculator: 2017 to 2026)
    if (els.selYear && els.selYear.options.length <= 1) {
      const curYr = els.selYear.value || 'all';
      els.selYear.innerHTML = '<option value="all">All Years (2017 - 2026)</option>';
      const allCalcYears = ['2026', '2025', '2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017'];
      const mergedYears = Array.from(new Set([...(state.availableYears || []), ...allCalcYears])).sort().reverse();
      mergedYears.forEach(y => {
        const opt = document.createElement('option');
        opt.value = y;
        opt.textContent = `${y}`;
        els.selYear.appendChild(opt);
      });
      if (curYr) els.selYear.value = curYr;
    }

    // Populate States if needed
    if (els.selState && els.selState.options.length <= 1) {
      const curSt = els.selState.value;
      els.selState.innerHTML = '<option value="all">All States / UTs</option>';
      state.availableStates.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.state_code;
        opt.textContent = s.state_name;
        els.selState.appendChild(opt);
      });
      if (curSt) els.selState.value = curSt;
    }
  }

  // Render top KPI cards
  function renderKPIs() {
    const s = state.summary;

    if (state.level === 'company') {
      els.kpiTitle1.textContent = 'Insurers Operating';
      els.kpiVal1.textContent = fmtNum(state.data.length);
      els.kpiSub1.textContent = 'Notified Insurance Companies';
    } else if (state.level === 'state') {
      els.kpiTitle1.textContent = 'State Reports';
      els.kpiVal1.textContent = fmtNum(state.data.length);
      els.kpiSub1.textContent = 'State & Insurer Allocations';
    } else if (state.level === 'district') {
      els.kpiTitle1.textContent = 'Districts Covered';
      els.kpiVal1.textContent = fmtNum(state.data.length);
      els.kpiSub1.textContent = 'District Insurance Units';
    } else { // crop
      els.kpiTitle1.textContent = 'Notified Crop Rates';
      els.kpiVal1.textContent = fmtNum(state.data.length);
      els.kpiSub1.textContent = 'Crop x District Combinations';
    }

    els.kpiVal2.textContent = fmtNum(s.total_farmers || 0);
    els.kpiVal3.textContent = fmtLakh(s.total_area_lakh_ha || 0);
    els.kpiVal4.textContent = fmtCrore(s.total_gross_premium_crore || 0);
    els.kpiVal5.textContent = fmtCrore(s.total_claims_paid_crore || 0);
    els.kpiVal6.textContent = `${(s.overall_loss_ratio_pct || 0).toFixed(1)}%`;
    if (els.kpiVal6 && els.kpiVal6.parentElement.querySelector('.kpi-sub')) {
      els.kpiVal6.parentElement.querySelector('.kpi-sub').textContent = `Prem Rate: ${(s.overall_premium_rate_pct || 0).toFixed(2)}%`;
    }
  }

  // Render Table
  function renderTable() {
    if (!els.tblHead || !els.tblBody) return;

    // Table title tags
    const yrText = state.year === 'all' ? 'All Years (2018-2026)' : `Year ${state.year}`;
    const snText = state.season === 'all' ? 'Both Seasons' : (state.season === '01' ? 'Kharif' : 'Rabi');
    const schText = state.scheme === 'all' ? 'PMFBY & RWBCIS' : (state.scheme === '02' ? 'PMFBY' : 'RWBCIS');
    els.tableFilterTag.textContent = `${yrText} • ${snText} • ${schText}`;

    if (state.level === 'crop') {
      els.tableTitleText.textContent = 'Official Crop-Wise Premium Rates & District Aggregate Rates';
      els.tblHead.innerHTML = `
        <tr>
          <th>#</th>
          <th>Crop Name</th>
          <th>Category</th>
          <th>State Name</th>
          <th>District Name</th>
          <th>Designated Insurer</th>
          <th>Year</th>
          <th>Season</th>
          <th>Scheme</th>
          <th>Crop Rate (%)</th>
          <th>Farmer Rate (%)</th>
          <th>Subsidy Rate (%)</th>
          <th>Sum Insured (₹/Ha)</th>
          <th>District Total Rate (%)</th>
          <th>District Hist LR</th>
          <th>Insurer Hist LR</th>
        </tr>`;

      if (state.data.length === 0) {
        els.tblBody.innerHTML = '<tr><td colspan="16" style="text-align:center; padding:32px; color:var(--text-secondary);">No crop records matched the selected criteria.</td></tr>';
        return;
      }

      els.tblBody.innerHTML = state.data.map((d, i) => {
        const schClass = d.scheme === 'RWBCIS' ? 'badge-scheme-rwbcis' : 'badge-scheme-pmfby';
        return `
          <tr>
            <td>${i + 1}</td>
            <td style="font-weight:700; color:var(--text-primary);">${d.crop_name}</td>
            <td><span class="badge-crop-cat">${d.crop_category || 'General'}</span></td>
            <td style="font-weight:600;">${d.state_name}</td>
            <td style="font-weight:700; color:#38bdf8;">${d.district_name}</td>
            <td><span class="badge-ic-pill" title="${d.insurance_company}">${d.insurance_company_short}</span></td>
            <td>${d.year}</td>
            <td><span class="badge-season">${d.season}</span></td>
            <td><span class="${schClass}">${d.scheme}</span></td>
            <td><span class="badge-rate-pill" style="background:rgba(2,132,199,0.15); color:#38bdf8;">${(Number(d.actuarial_rate_pct) || 0).toFixed(2)}%</span></td>
            <td style="font-family:'Fira Code',monospace;">${(Number(d.farmer_rate_pct) || 0).toFixed(2)}%</td>
            <td style="font-family:'Fira Code',monospace;">${(Number(d.total_subsidy_rate_pct) || 0).toFixed(2)}%</td>
            <td style="font-family:'Fira Code',monospace; font-weight:600;">₹${fmtNum(d.sum_insured_per_ha)}</td>
            <td>${getRateBadge(d.district_premium_rate_pct)}</td>
            <td>${getLrBadge(d.district_historical_lr_pct, 'District Historical Loss Ratio across all years')}</td>
            <td>${getLrBadge(d.company_historical_lr_pct, 'Insurer Historical Loss Ratio across all years')}</td>
          </tr>`;
      }).join('');

    } else if (state.level === 'district') {
      els.tableTitleText.textContent = 'District-Wise Insurance Company Allocation, Premium Rate & Loss Ratio';
      els.tblHead.innerHTML = `
        <tr>
          <th>#</th>
          <th>State</th>
          <th>District Name</th>
          <th>Designated Insurer</th>
          <th>Year</th>
          <th>Season</th>
          <th>Scheme</th>
          <th>Farmers Enrolled</th>
          <th>Sum Insured</th>
          <th>Gross Premium</th>
          <th>District Rate (%)</th>
          <th>Farmer Rate (%)</th>
          <th>Claims Paid</th>
          <th>Current LR</th>
          <th>Historical LR</th>
          <th>Crops</th>
        </tr>`;

      if (state.data.length === 0) {
        els.tblBody.innerHTML = '<tr><td colspan="16" style="text-align:center; padding:32px; color:var(--text-secondary);">No district records matched the selected criteria.</td></tr>';
        return;
      }

      els.tblBody.innerHTML = state.data.map((d, i) => {
        const schClass = d.scheme === 'RWBCIS' ? 'badge-scheme-rwbcis' : 'badge-scheme-pmfby';
        const safeDistName = (d.district_name || '').replace(/'/g, "\\'");
        return `
          <tr>
            <td>${i + 1}</td>
            <td style="font-weight:600;">${d.state_name}</td>
            <td style="font-weight:700; color:var(--text-primary);">${d.district_name}</td>
            <td><span class="badge-ic-pill" title="${d.insurance_company}">${d.insurance_company_short}</span></td>
            <td>${d.year}</td>
            <td><span class="badge-season">${d.season}</span></td>
            <td><span class="${schClass}">${d.scheme}</span></td>
            <td style="font-weight:600;">${fmtNum(d.farmer_count)}</td>
            <td>${fmtCrore(d.sum_insured_crore)}</td>
            <td style="font-weight:600;">${fmtCrore(d.gross_premium_crore)}</td>
            <td>${getRateBadge(d.district_premium_rate_pct)}</td>
            <td style="font-family:'Fira Code',monospace;">${(Number(d.farmer_premium_rate_pct) || 0).toFixed(2)}%</td>
            <td style="color:#ef4444; font-weight:600;">${fmtCrore(d.claims_paid_crore)}</td>
            <td>${getLrBadge(d.loss_ratio_pct, 'Current Season Loss Ratio')}</td>
            <td>${getLrBadge(d.historical_loss_ratio_pct, 'Cumulative District Historical Loss Ratio across all years')}</td>
            <td>
              <button class="btn-crop-action" onclick="window.viewDistrictCrops('${d.state_code}', '${safeDistName}', '${d.year}', '${d.insurance_company_short}')" title="Inspect official notified crop rates for this district">
                <i class="fa-solid fa-wheat-awn"></i> Crops
              </button>
            </td>
          </tr>`;
      }).join('');

    } else if (state.level === 'state') {
      els.tableTitleText.textContent = 'State-Wise Insurance Company Distribution, Premium Rate & Loss Ratio';
      els.tblHead.innerHTML = `
        <tr>
          <th>#</th>
          <th>State Name</th>
          <th>Designated Insurer</th>
          <th>Year</th>
          <th>Season</th>
          <th>Scheme</th>
          <th>Districts Covered</th>
          <th>Farmers Enrolled</th>
          <th>Sum Insured</th>
          <th>Gross Premium</th>
          <th>State Rate (%)</th>
          <th>Claims Paid</th>
          <th>Current LR</th>
          <th>Historical LR</th>
        </tr>`;

      if (state.data.length === 0) {
        els.tblBody.innerHTML = '<tr><td colspan="14" style="text-align:center; padding:32px; color:var(--text-secondary);">No state records matched the selected criteria.</td></tr>';
        return;
      }

      els.tblBody.innerHTML = state.data.map((d, i) => {
        const schClass = d.scheme === 'RWBCIS' ? 'badge-scheme-rwbcis' : 'badge-scheme-pmfby';
        return `
          <tr>
            <td>${i + 1}</td>
            <td style="font-weight:700; color:var(--text-primary);">${d.state_name}</td>
            <td><span class="badge-ic-pill" title="${d.insurance_company}">${d.insurance_company_short}</span></td>
            <td>${d.year}</td>
            <td><span class="badge-season">${d.season}</span></td>
            <td><span class="${schClass}">${d.scheme}</span></td>
            <td><strong>${d.districts_count}</strong> Dist</td>
            <td style="font-weight:600;">${fmtNum(d.farmer_count)}</td>
            <td>${fmtCrore(d.sum_insured_crore)}</td>
            <td style="font-weight:600;">${fmtCrore(d.gross_premium_crore)}</td>
            <td>${getRateBadge(d.state_premium_rate_pct)}</td>
            <td style="color:#ef4444; font-weight:600;">${fmtCrore(d.claims_paid_crore)}</td>
            <td>${getLrBadge(d.loss_ratio_pct, 'Current Season Loss Ratio')}</td>
            <td>${getLrBadge(d.historical_loss_ratio_pct, 'State Historical Loss Ratio across all years')}</td>
          </tr>`;
      }).join('');

    } else { // Company level
      els.tableTitleText.textContent = 'Insurance Company Portfolio Leaderboard, Premium Rate & Historical Loss Ratio';
      els.tblHead.innerHTML = `
        <tr>
          <th>Rank</th>
          <th>Insurance Company</th>
          <th>Districts</th>
          <th>States</th>
          <th>Farmers Enrolled</th>
          <th>Sum Insured</th>
          <th>Gross Premium</th>
          <th>Company Rate (%)</th>
          <th>Govt Subsidy (₹ Cr)</th>
          <th>Claims Settled</th>
          <th>Current LR</th>
          <th>Historical LR</th>
        </tr>`;

      if (state.data.length === 0) {
        els.tblBody.innerHTML = '<tr><td colspan="12" style="text-align:center; padding:32px; color:var(--text-secondary);">No company records matched the selected criteria.</td></tr>';
        return;
      }

      els.tblBody.innerHTML = state.data.map((d, i) => {
        const totalSubsidy = (d.goi_share_crore || 0) + (d.state_share_crore || 0);
        return `
          <tr>
            <td style="font-weight:700; color:#0284c7;">#${i + 1}</td>
            <td>
              <span class="badge-ic-pill" style="font-size:13px;" title="${d.company_name}">${d.company_short}</span>
            </td>
            <td><strong>${fmtNum(d.districts_count)}</strong> Districts</td>
            <td><strong>${fmtNum(d.states_count)}</strong> States</td>
            <td style="font-weight:700; color:var(--text-primary); font-size:13px;">${fmtNum(d.farmer_count)}</td>
            <td>${fmtCrore(d.sum_insured_crore)}</td>
            <td style="font-weight:600;">${fmtCrore(d.gross_premium_crore)}</td>
            <td>${getRateBadge(d.company_premium_rate_pct)}</td>
            <td>${fmtCrore(totalSubsidy)}</td>
            <td style="color:#ef4444; font-weight:700;">${fmtCrore(d.claims_paid_crore)}</td>
            <td>${getLrBadge(d.loss_ratio_pct, 'Current Season Loss Ratio')}</td>
            <td>${getLrBadge(d.historical_loss_ratio_pct, 'Cumulative Insurer Historical Loss Ratio across all years')}</td>
          </tr>`;
      }).join('');
    }
  }

  // Render Visualizations with Chart.js
  function renderCharts() {
    if (typeof Chart === 'undefined') return;

    // Palette
    const colors = [
      '#0284c7', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899',
      '#06b6d4', '#84cc16', '#f97316', '#6366f1', '#14b8a6',
      '#a855f7', '#eab308', '#64748b', '#d946ef', '#3b82f6'
    ];

    const top10 = state.data.slice(0, 10);

    if (state.level === 'crop') {
      // 1. Chart 1: Top Notified Crops by Actuarial Premium Rate (%)
      const labels1 = top10.map(d => `${d.crop_name} (${d.district_name})`);
      const vals1 = top10.map(d => Number(d.actuarial_rate_pct) || 0);

      if (state.charts.share) state.charts.share.destroy();
      state.charts.share = new Chart(els.chartCompanyShare, {
        type: 'doughnut',
        data: {
          labels: labels1,
          datasets: [{
            data: vals1,
            backgroundColor: colors.slice(0, labels1.length),
            borderWidth: 2,
            borderColor: '#1e293b'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'right', labels: { color: '#94a3b8', boxWidth: 12, font: { size: 10 } } },
            tooltip: {
              callbacks: {
                label: (ctx) => ` ${ctx.label}: ${ctx.raw.toFixed(2)}% Premium Rate`
              }
            }
          }
        }
      });

      // 2. Chart 2: Crop Actuarial Rate (%) vs District Total Rate (%)
      const labels2 = top10.map(d => `${d.crop_name} - ${d.district_name}`);
      const cropRates = top10.map(d => Number(d.actuarial_rate_pct) || 0);
      const distRates = top10.map(d => Number(d.district_premium_rate_pct) || 0);

      if (state.charts.premClaim) state.charts.premClaim.destroy();
      state.charts.premClaim = new Chart(els.chartPremiumClaims, {
        type: 'bar',
        data: {
          labels: labels2,
          datasets: [
            { label: 'Crop Actuarial Rate (%)', data: cropRates, backgroundColor: '#0284c7', borderRadius: 4 },
            { label: 'District Weighted Rate (%)', data: distRates, backgroundColor: '#10b981', borderRadius: 4 }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: { ticks: { color: '#94a3b8', font: { size: 9 }, maxRotation: 45 }, grid: { display: false } },
            y: { ticks: { color: '#94a3b8', callback: v => `${v}%` }, grid: { color: 'rgba(255,255,255,0.05)' } }
          },
          plugins: {
            legend: { labels: { color: '#94a3b8' } },
            tooltip: { callbacks: { label: ctx => ` ${ctx.dataset.label}: ${ctx.raw.toFixed(2)}%` } }
          }
        }
      });

      // 3. Chart 3: District Historical Loss Ratio (%)
      const distLrVals = top10.map(d => Number(d.district_historical_lr_pct) || 0);
      const distLrColors = distLrVals.map(v => v > 100 ? '#ef4444' : (v > 75 ? '#f59e0b' : '#10b981'));

      if (state.charts.lr) state.charts.lr.destroy();
      state.charts.lr = new Chart(els.chartLossRatio, {
        type: 'bar',
        data: {
          labels: labels2,
          datasets: [{
            label: 'District Historical LR (%)',
            data: distLrVals,
            backgroundColor: distLrColors,
            borderRadius: 4
          }]
        },
        options: {
          indexAxis: 'y',
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: { ticks: { color: '#94a3b8', callback: v => `${v}%` }, grid: { color: 'rgba(255,255,255,0.05)' } },
            y: { ticks: { color: '#94a3b8', font: { size: 9 } }, grid: { display: false } }
          },
          plugins: {
            legend: { display: false },
            tooltip: { callbacks: { label: ctx => ` Historical LR: ${ctx.raw.toFixed(1)}%` } }
          }
        }
      });

      // 4. Chart 4: Crop Category Distribution
      const catCount = {};
      state.data.forEach(c => {
        const cat = c.crop_category || 'Other Crops';
        catCount[cat] = (catCount[cat] || 0) + 1;
      });
      const catLabels = Object.keys(catCount);
      const catVals = Object.values(catCount);

      if (state.charts.scheme) state.charts.scheme.destroy();
      state.charts.scheme = new Chart(els.chartSchemeSeason, {
        type: 'pie',
        data: {
          labels: catLabels,
          datasets: [{
            data: catVals,
            backgroundColor: colors.slice(0, catLabels.length),
            borderColor: '#1e293b',
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'bottom', labels: { color: '#94a3b8', font: { size: 10 } } },
            tooltip: { callbacks: { label: ctx => ` ${ctx.label}: ${fmtNum(ctx.raw)} Notified Crops` } }
          }
        }
      });

    } else {
      // Company / State / District default charts
      // Chart 1: Market Share
      const labels1 = top10.map(d => state.level === 'company' ? d.company_short : (state.level === 'state' ? `${d.state_name} (${d.insurance_company_short})` : d.district_name));
      const vals1 = top10.map(d => d.farmer_count || 0);

      if (state.charts.share) state.charts.share.destroy();
      state.charts.share = new Chart(els.chartCompanyShare, {
        type: 'doughnut',
        data: {
          labels: labels1,
          datasets: [{
            data: vals1,
            backgroundColor: colors.slice(0, labels1.length),
            borderWidth: 2,
            borderColor: '#1e293b'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'right', labels: { color: '#94a3b8', boxWidth: 12, font: { size: 11 } } },
            tooltip: {
              callbacks: {
                label: (ctx) => ` ${ctx.label}: ${fmtNum(ctx.raw)} Farmers`
              }
            }
          }
        }
      });

      // Chart 2: Premium vs Claims Settled
      const labels2 = top10.map(d => state.level === 'company' ? d.company_short : (state.level === 'state' ? d.state_name : d.district_name));
      const premVals = top10.map(d => d.gross_premium_crore || 0);
      const claimVals = top10.map(d => d.claims_paid_crore || 0);

      if (state.charts.premClaim) state.charts.premClaim.destroy();
      state.charts.premClaim = new Chart(els.chartPremiumClaims, {
        type: 'bar',
        data: {
          labels: labels2,
          datasets: [
            { label: 'Gross Premium (₹ Cr)', data: premVals, backgroundColor: '#0284c7', borderRadius: 4 },
            { label: 'Claims Paid (₹ Cr)', data: claimVals, backgroundColor: '#ef4444', borderRadius: 4 }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: { ticks: { color: '#94a3b8', font: { size: 10 } }, grid: { display: false } },
            y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } }
          },
          plugins: {
            legend: { labels: { color: '#94a3b8' } }
          }
        }
      });

      // Chart 3: Loss Ratio (%)
      const lrVals = top10.map(d => d.loss_ratio_pct || 0);
      const lrColors = lrVals.map(v => v > 100 ? '#ef4444' : (v > 75 ? '#f59e0b' : '#10b981'));

      if (state.charts.lr) state.charts.lr.destroy();
      state.charts.lr = new Chart(els.chartLossRatio, {
        type: 'bar',
        data: {
          labels: labels2,
          datasets: [{
            label: 'Loss Ratio (%)',
            data: lrVals,
            backgroundColor: lrColors,
            borderRadius: 4
          }]
        },
        options: {
          indexAxis: 'y',
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: { ticks: { color: '#94a3b8', callback: v => `${v}%` }, grid: { color: 'rgba(255,255,255,0.05)' } },
            y: { ticks: { color: '#94a3b8', font: { size: 10 } }, grid: { display: false } }
          },
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                label: ctx => ` Loss Ratio: ${ctx.raw.toFixed(1)}%`
              }
            }
          }
        }
      });

      // Chart 4: Season / Scheme Distribution
      const pmfbyFarmers = state.data.reduce((acc, d) => (d.schemes && d.schemes.includes('PMFBY')) || d.scheme === 'PMFBY' ? acc + (d.farmer_count || 0) : acc, 0);
      const rwbcisFarmers = state.data.reduce((acc, d) => (d.schemes && d.schemes.includes('RWBCIS')) || d.scheme === 'RWBCIS' ? acc + (d.farmer_count || 0) : acc, 0);

      if (state.charts.scheme) state.charts.scheme.destroy();
      state.charts.scheme = new Chart(els.chartSchemeSeason, {
        type: 'pie',
        data: {
          labels: ['PMFBY (Yield-Based)', 'RWBCIS (Weather-Based)'],
          datasets: [{
            data: [pmfbyFarmers, rwbcisFarmers],
            backgroundColor: ['#10b981', '#f59e0b'],
            borderColor: '#1e293b',
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'bottom', labels: { color: '#94a3b8' } },
            tooltip: {
              callbacks: {
                label: ctx => ` ${ctx.label}: ${fmtNum(ctx.raw)} Farmers`
              }
            }
          }
        }
      });
    }
  }

  // Global helper to view district crops
  window.viewDistrictCrops = function (stCode, distName, yr, comp) {
    state.level = 'crop';
    [els.btnLevelCompany, els.btnLevelState, els.btnLevelDistrict, els.btnLevelCrop].forEach(b => {
      if (b) b.classList.toggle('active', b.dataset.level === 'crop');
    });
    if (distName) {
      state.search = distName;
      if (els.txtSearch) els.txtSearch.value = distName;
    }
    fetchData();
  };

  // Setup Event Handlers
  function setupEvents() {
    // Level selection pills
    function setLevel(lvl) {
      state.level = lvl;
      [els.btnLevelCompany, els.btnLevelState, els.btnLevelDistrict, els.btnLevelCrop].forEach(b => {
        if (b) b.classList.toggle('active', b.dataset.level === lvl);
      });
      fetchData();
    }

    if (els.btnLevelCompany) els.btnLevelCompany.addEventListener('click', () => setLevel('company'));
    if (els.btnLevelState) els.btnLevelState.addEventListener('click', () => setLevel('state'));
    if (els.btnLevelDistrict) els.btnLevelDistrict.addEventListener('click', () => setLevel('district'));
    if (els.btnLevelCrop) els.btnLevelCrop.addEventListener('click', () => setLevel('crop'));

    // Filter selectors
    if (els.selCompany) {
      els.selCompany.addEventListener('change', () => {
        state.company = els.selCompany.value;
        fetchData();
      });
    }

    if (els.selYear) {
      els.selYear.addEventListener('change', () => {
        state.year = els.selYear.value;
        fetchData();
      });
    }

    if (els.selSeason) {
      els.selSeason.addEventListener('change', () => {
        state.season = els.selSeason.value;
        fetchData();
      });
    }

    if (els.selScheme) {
      els.selScheme.addEventListener('change', () => {
        state.scheme = els.selScheme.value;
        fetchData();
      });
    }

    if (els.selState) {
      els.selState.addEventListener('change', () => {
        state.stateCode = els.selState.value;
        fetchData();
      });
    }

    if (els.txtSearch) {
      let timeout = null;
      els.txtSearch.addEventListener('input', () => {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
          state.search = els.txtSearch.value;
          fetchData();
        }, 300);
      });
    }

    // Refresh Sync button
    if (els.btnRefreshSync) {
      els.btnRefreshSync.addEventListener('click', triggerManualSync);
    }

    // Theme Toggle
    if (els.themeToggleBtn) {
      els.themeToggleBtn.addEventListener('click', () => {
        document.body.classList.toggle('light-theme');
        const isLight = document.body.classList.contains('light-theme');
        const icon = els.themeToggleBtn.querySelector('i');
        if (icon) icon.className = isLight ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
      });
    }

    // Polling for daily sync check every 10 minutes
    setInterval(fetchSyncStatus, 10 * 60 * 1000);
  }

  // Init
  function init() {
    setupEvents();
    fetchSyncStatus();
    fetchData();
  }

  document.addEventListener('DOMContentLoaded', init);

})();
